@echo off
setlocal
cd /d "%~dp0"
cd ..
echo Starting Hacker rsvx7 Ai Agent v1.2.0...
if exist "%SystemRoot%\py.exe" (
  py -3 agent\run_agent.py
) else (
  python agent\run_agent.py
)
endlocal
