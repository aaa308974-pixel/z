#!/bin/sh
set -eu
cd "$(dirname "$0")"
python3 scripts/start_local.py "$@"
