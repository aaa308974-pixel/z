import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { gzipSync, brotliCompressSync, constants } from "node:zlib";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../frontend/build");
if (!fs.existsSync(path.join(root, "index.html"))) throw new Error("Production frontend build is missing");
// Keep only this release's hashed chunks. Some build hosts retain old output
// files between builds; those files must not ship as stale public code/maps.
const manifest = JSON.parse(fs.readFileSync(path.join(root, "asset-manifest.json"), "utf8"));
const assets = new Set(Object.values(manifest.files).map(value => value.replace(/^\//, "")));
function prune(directory) {
  if (!fs.existsSync(directory)) return;
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const target = path.join(directory, entry.name);
    if (entry.isDirectory()) { prune(target); continue; }
    const relative = path.relative(root, target).split(path.sep).join("/");
    const base = relative.replace(/\.(gz|br)$/, "");
    const licensedAsset = base.endsWith(".LICENSE.txt") ? base.slice(0, -".LICENSE.txt".length) : null;
    if (!assets.has(base) && !(licensedAsset && assets.has(licensedAsset))) fs.unlinkSync(target);
  }
}
prune(path.join(root, "static"));
let files = 0, raw = 0, gzip = 0, brotli = 0;
function visit(directory) {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const target = path.join(directory, entry.name);
    if (entry.isDirectory()) { visit(target); continue; }
    if (!/\.(js|css|json|svg)$/.test(entry.name)) continue;
    const data = fs.readFileSync(target);
    if (data.length < 256) continue;
    const gz = gzipSync(data, { level: 9 });
    const br = brotliCompressSync(data, { params: { [constants.BROTLI_PARAM_QUALITY]: 5 } });
    fs.writeFileSync(target + ".gz", gz); fs.writeFileSync(target + ".br", br);
    files += 1; raw += data.length; gzip += gz.length; brotli += br.length;
  }
}
visit(root);
console.log(`Precompressed ${files} assets: raw=${raw}, gzip=${gzip}, brotli=${brotli} bytes`);
