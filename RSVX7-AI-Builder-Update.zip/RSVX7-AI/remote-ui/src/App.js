import "@/App.css";
import { HashRouter, Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "sonner";
import { AuthProvider, useAuth } from "@/context/AuthContext";
import DashboardLayout from "@/components/DashboardLayout";
import Dashboard from "@/pages/Dashboard";
import Servers from "@/pages/Servers";
import Devices from "@/pages/Devices";
import ManageDevice from "@/pages/ManageDevice";
import Workspace from "@/pages/Workspace";
import FileManager from "@/pages/FileManager";
import Monitor from "@/pages/Monitor";
import Docker from "@/pages/Docker";
import Logs from "@/pages/Logs";
import AgentDownloads from "@/pages/AgentDownloads";

function Protected({children}) {
 const {user,loading}=useAuth();
 if(loading)return <div className="p-8 text-white">جارٍ فتح مساحة الأجهزة…</div>;
 if(!user)return <div className="p-8 text-white"><a href="/#login" target="_top">سجّل الدخول إلى المنصة</a></div>;
 return children;
}

function App() {
  return (
    <div className="App">
      <AuthProvider>
        <Toaster theme="dark" position="bottom-right" richColors />
        <HashRouter>
          <Routes>
            <Route path="/" element={<Navigate to="/app" replace />} />


            <Route
              path="/app"
              element={
                <Protected>
                  <DashboardLayout />
                </Protected>
              }
            >
              <Route index element={<Dashboard />} />
              <Route path="servers" element={<Servers />} />
              <Route path="devices" element={<Devices />} />
              <Route path="devices/:id" element={<ManageDevice />} />
              <Route path="agent-downloads" element={<AgentDownloads />} />
              <Route path="workspace" element={<Workspace />} />
              <Route path="files" element={<FileManager />} />
              <Route path="monitor" element={<Monitor />} />
              <Route path="docker" element={<Docker />} />
              <Route path="logs" element={<Logs />} />

            </Route>
          </Routes>
        </HashRouter>
      </AuthProvider>
    </div>
  );
}

export default App;
