import { useEffect, useState } from "react";
import { motion, useReducedMotion } from "framer-motion";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import rehypeHighlight from "rehype-highlight";
import { Activity, Check, CheckCircle2, ChevronDown, Clock3, Copy, Loader2,
  Search, ShieldCheck, TerminalSquare, Wrench, XCircle } from "lucide-react";
import { terminalStatuses } from "../lib/task-events";
import "./task-progress.css";

const TEXT = {
  en: { inspect: "Inspect", execute: "Execute", repair: "Repair", verify: "Verify", working: "Working on your request",
    success: "Requested result verified", blocked: "Needs attention", cancelled: "Task stopped", answered: "Answer",
    interrupted: "Connection interrupted", auto: "Automatic execution", step: "Step", commands: "commands", output: "Live output",
    result: "Final result", details: "Execution details", waiting: "Waiting for output…", copy: "Copy result", check: "Verified evidence" },
  ar: { inspect: "فحص", execute: "تنفيذ", repair: "إصلاح", verify: "تحقق", working: "جاري إنجاز طلبك",
    success: "تم التحقق من النتيجة المطلوبة", blocked: "تعذر إكمال الطلب", cancelled: "تم إيقاف المهمة", answered: "الإجابة",
    interrupted: "انقطع الاتصال", auto: "تنفيذ تلقائي", step: "خطوة", commands: "أوامر", output: "نتيجة مباشرة",
    result: "النتيجة النهائية", details: "تفاصيل التنفيذ", waiting: "بانتظار نتيجة الأمر…", copy: "نسخ النتيجة", check: "دليل التحقق" },
};
const STAGES = [{ key: "inspect", icon: Search }, { key: "execute", icon: TerminalSquare },
  { key: "repair", icon: Wrench }, { key: "verify", icon: ShieldCheck }];

function useElapsed(turn, active) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    if (!active) return undefined;
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, [active]);
  const seconds = Math.max(0, Math.round(turn.duration ?? (now / 1000 - turn.started_at)));
  return seconds < 60 ? seconds + "s" : Math.floor(seconds / 60) + "m " + (seconds % 60) + "s";
}

export default function TaskProgress({ turn }) {
  const reducedMotion = useReducedMotion();
  const text = TEXT[turn.language] || TEXT.en;
  const active = !terminalStatuses.has(turn.phase);
  const elapsed = useElapsed(turn, active);
  const good = turn.status === "success" && turn.verified;
  const blocked = ["blocked", "interrupted"].includes(turn.status);
  const Icon = active ? Activity : good ? CheckCircle2 : blocked ? XCircle : Check;
  const answer = active ? turn.answer : (turn.summary || turn.answer);
  const showProgress = active || turn.steps.length > 0 || blocked || turn.status === "cancelled";
  const statusText = active ? text.working : good ? text.success : text[turn.status] || text.blocked;
  return <div className="rounded-2xl rounded-bl-sm border border-white/10 bg-white/[0.025] overflow-hidden task-turn" dir={turn.language === "ar" ? "rtl" : "ltr"}>
    {showProgress && <div className="px-4 pt-4 pb-3" data-testid="execution-progress" role="status" aria-live="polite">
      <div className="flex items-center gap-3">
        <div className={"task-orb " + (active ? "is-active" : good ? "is-success" : blocked ? "is-blocked" : "")}>
          <Icon className="w-4 h-4" />
        </div>
        <div className="min-w-0 flex-1">
          <div className={"text-[13px] font-medium " + (good ? "text-emerald-400" : blocked ? "text-amber-300" : "text-white/90")}>{statusText}</div>
          <div className="mt-1 flex items-center gap-2 text-[10px] text-white/40">
            <span className="flex items-center gap-1"><Clock3 className="w-3 h-3" />{elapsed}</span>
            <span>·</span><span>{turn.steps.length} {text.commands}</span>
            {active && <span className="task-live-dot" />}
          </div>
        </div>
      </div>
      <div className="grid grid-cols-4 gap-1 mt-4" aria-label={text.details}>
        {STAGES.map(({ key, icon: StageIcon }) => {
          const current = active && turn.stage === key;
          const complete = turn.steps.some((step) => step.stage === key && step.status === "success");
          return <div key={key} className={"task-stage " + (current ? "is-current" : complete ? "is-complete" : "") }>
            <StageIcon className="w-3 h-3 shrink-0" /><span>{text[key]}</span>
          </div>;
        })}
      </div>
      {active && <div className="task-track mt-3"><div className="task-shimmer" /></div>}
      {active && <motion.p key={turn.activity} initial={reducedMotion ? false : { opacity: 0, y: 3 }} animate={{ opacity: 1, y: 0 }}
        className="text-xs text-white/60 mt-3 leading-relaxed min-h-4">{turn.activity || text.working}</motion.p>}
    </div>}
    {turn.steps.length > 0 && <div className="px-4 pb-3 space-y-2" data-testid="task-steps">
      {turn.steps.map((step) => <CommandStep key={step.step_id} step={step} text={text} reducedMotion={reducedMotion} />)}
    </div>}
    {answer && <motion.div initial={reducedMotion ? false : { opacity: 0 }} animate={{ opacity: 1 }}
      className={"px-4 py-4 " + (showProgress ? "border-t border-white/10" : "")} data-testid="task-final-result">
      {showProgress && <div className="flex items-center justify-between mb-3">
        <span className="text-[10px] uppercase tracking-wider text-white/40">{text.result}</span>
        <button title={text.copy} aria-label={text.copy} onClick={() => navigator.clipboard.writeText(answer)} className="text-white/40 hover:text-white"><Copy className="w-3.5 h-3.5" /></button>
      </div>}
      <div className="md-body text-sm"><ReactMarkdown remarkPlugins={[remarkGfm]} rehypePlugins={[rehypeHighlight]}>{answer}</ReactMarkdown></div>
      {good && turn.evidence.length > 0 && <div className="mt-3 rounded-xl border border-emerald-500/15 bg-emerald-500/5 p-3 text-xs text-emerald-300/80 space-y-1.5" data-testid="task-verification">
        <div className="flex items-center gap-1.5 font-medium"><ShieldCheck className="w-3.5 h-3.5" />{text.check}</div>
        {turn.evidence.map((item, index) => <p key={index}>{text.step} {item.step_id} · {item.finding}</p>)}
      </div>}
    </motion.div>}
  </div>;
}

function CommandStep({ step, text, reducedMotion }) {
  const [expanded, setExpanded] = useState(false);
  const running = step.status === "running";
  const failed = step.status === "failed";
  const open = expanded || running;
  return <motion.div initial={reducedMotion ? false : { opacity: 0, y: 5 }} animate={{ opacity: 1, y: 0 }}
    className={"task-command " + (running ? "is-running" : failed ? "is-failed" : "")} data-testid="command-card">
    <button onClick={() => setExpanded(!expanded)} className="w-full flex items-start gap-2.5 px-3 py-2.5 text-start" aria-expanded={open}>
      <span className="mt-0.5 shrink-0">{running ? <Loader2 className="w-3.5 h-3.5 animate-spin text-gold" />
        : step.status === "success" ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
          : <XCircle className={"w-3.5 h-3.5 " + (failed ? "text-amber-400" : "text-white/40")} />}</span>
      <span className="flex-1 min-w-0"><span className="block text-[10px] text-white/40 mb-0.5">{text.step} {step.step_id} · {text[step.stage] || text.execute}</span>
        <span className="text-xs text-white/80 leading-relaxed">{step.explanation || text.auto}</span></span>
      <ChevronDown className={"w-3 h-3 mt-1 shrink-0 text-white/30 transition-transform " + (open ? "rotate-180" : "")} />
    </button>
    {open && <div className="border-t border-white/8" dir="ltr">
      <pre className="!m-0 !rounded-none px-3 py-2 text-[11px] whitespace-pre-wrap break-all text-white/70 font-mono bg-white/[0.02]">{step.command}</pre>
      <div className="px-3 py-1.5 border-t border-white/8 flex items-center justify-between text-[10px] text-white/40">
        <span className="flex items-center gap-1"><TerminalSquare className="w-3 h-3" />{text.output}</span>
        {step.exit_code != null && <span data-testid="exit-badge" className={failed ? "text-amber-400" : "text-emerald-400"}>exit {step.exit_code} · {step.duration ?? "—"}s</span>}
      </div>
      <pre className="!m-0 !rounded-none px-3 py-2 text-[11px] max-h-48 overflow-auto whitespace-pre-wrap text-white/70 font-mono bg-black/40" data-testid="command-output">{step.output || (running ? text.waiting : "(no output)")}</pre>
    </div>}
  </motion.div>;
}
