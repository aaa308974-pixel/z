import { createServer } from 'node:http';
import { spawn, execFile } from 'node:child_process';
import { once } from 'node:events';
import { mkdtemp, mkdir, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';
import { source, criteria } from './fixtures/agent-fixtures.mjs';
const calls = [], requests = [], secret = 'fixture-only-private-builder-engine-secret-000000';
let mode = 'planning', checks = 0, planningAttempts = 0, coderFailures = 0, lastActivity = [];
const proposal = { kind: 'proposal', title: 'Portfolio', summary: 'Show skills', pages: [{name:'Home',purpose:'Show work'}], features:['CV'], design:'Modern', steps:['Implement'] };
const questionPlan = { kind: 'questions', message: 'لنحدد الفكرة.', questions: [
  { id: 'goal', label: 'ما هدف الموقع؟', options: ['متجر', 'موقع شخصي'], multiple: false },
  { id: 'features', label: 'ما الميزات المطلوبة؟', options: ['حجز', 'تواصل'], multiple: true },
] };
const check = (actual, expected, label) => { assert.deepEqual(actual, expected, label); checks++; console.log('PASS', label); };
const mock = createServer(async (req, res) => {
  let raw = ''; for await (const chunk of req) raw += chunk;
  const body = JSON.parse(raw); requests.push(body);
  assert.equal(req.headers.authorization, 'Bearer fixture-request-scope');
  assert.equal(req.url, '/api/builder/internal/model');
  const system = body.messages[0].content;
  const role = ['builder','file_planner','file_reviewer'].includes(body.role) ? body.role : undefined; calls.push(role || 'planning');
  assert.equal(body.stream, true, 'The engine uses the incremental model bridge');
  let text;
  if (role) assert.equal(body.jsonMode, true, 'Direct generation requests complete file JSON');
  if (mode.startsWith('planning')) assert.equal(body.jsonMode, true, 'Planning requests the structured output contract');
  if (mode === 'planning') text = JSON.stringify(questionPlan);
  else if (mode === 'planning_answers') {
    assert.deepEqual(JSON.parse(body.messages.at(-2).content), questionPlan, 'Question IDs and every option survive in model history');
    assert.ok(body.messages.at(-1).content.includes('حجز، تواصل'), 'All selected answers reach the model together');
    assert.ok(system.includes('Builder output contracts below control response format'));
    text = JSON.stringify(proposal);
  }
  else if (mode === 'planning_wrapped') text = 'Here is the plan:\n```json\n' + JSON.stringify(proposal).replace('"steps":["Implement"]}', '"steps":["Implement"],}') + '\n```';
  else if (mode === 'planning_repair') {
    planningAttempts++;
    if (planningAttempts === 1) text = JSON.stringify({...proposal, pages:['Home']});
    else {
      assert.ok(body.messages.at(-1).content.includes('pages.0'));
      assert.ok(body.messages.at(-2).content.includes('"pages":["Home"]'));
      text = JSON.stringify(proposal);
    }
  }
  else if (mode === 'planning_invalid') text = JSON.stringify({...proposal, steps: undefined});
  else if (mode === 'planning_truncated') text = JSON.stringify(proposal).slice(0,-10);
  else if (mode === 'planning_ambiguous') text = JSON.stringify(proposal) + '\n' + JSON.stringify({...proposal,title:'Other'});
  else if (mode === 'planning_ambiguous_wrapped') text = '<studioPlan>' + JSON.stringify(proposal) + '</studioPlan><studioPlan>' + JSON.stringify({...proposal,title:'Other'}) + '</studioPlan>';
  else if (mode === 'planning_duplicate_options') text = JSON.stringify({...questionPlan, questions: [{...questionPlan.questions[0], options:['نعم','نعم']}]});
  else if (role === 'file_planner') text = JSON.stringify({files:mode==='repair_focus'?['z-broken.js']:Object.keys(source)});
  else if (role === 'file_reviewer') text = JSON.stringify({actions:[],remainingFiles:[]});
  else if (mode === 'build_bad' || (mode === 'build_recovery' && coderFailures++ < 1)) text = 'Not a file response';
  else {
    assert.equal(role, 'builder');
    const handoff = JSON.parse(system.split('CURRENT BATCH (data):\n')[1].split('\nPROJECT CONTEXT')[0]);
    assert.ok(!system.includes('DARKFORGE_AGENT:'));
    assert.ok(!system.includes('TEAM HANDOFF')); 
    if (mode === 'build_recovery' && handoff.validationFeedback) assert.ok(body.messages.at(-1).content.includes('validation feedback'));
    const assigned=handoff.requiredFiles.length ? handoff.requiredFiles : Object.keys(source).slice(0,2);
    text = JSON.stringify({actions:assigned.map(filePath=>({type:'file',filePath,content:mode==='repair_focus'?'export const fixed = true;':source[filePath]})),remainingFiles:handoff.requiredFiles.length ? [] : Object.keys(source).slice(2)});
  }
  if (mode === 'build_stream') {
    res.writeHead(200, {'Content-Type':'application/x-ndjson'});
    const frames='\n'+JSON.stringify({type:'delta',text:text.slice(0,57)})+'\r\n'+JSON.stringify({type:'delta',text:text.slice(57)})+'\n'+JSON.stringify({type:'result',finishReason:'stop'})+'\n';
    for(const byte of Buffer.from(frames)) res.write(Buffer.from([byte]));
    res.end(); return;
  }
  res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ text, finishReason: 'stop' }));
});
mock.listen(0, '127.0.0.1'); await once(mock, 'listening');
const reservation = createServer(); reservation.listen(0, '127.0.0.1'); await once(reservation, 'listening');
const port = reservation.address().port; await new Promise(resolve => reservation.close(resolve));
const engine = spawn(process.execPath, [fileURLToPath(new URL('./dist/service.mjs', import.meta.url))], { env: { ...process.env, BUILDER_ENGINE_PORT: String(port), BUILDER_ENGINE_SECRET: secret, BUILDER_API_ORIGIN: 'http://127.0.0.1:' + mock.address().port }, stdio: ['ignore', 'pipe', 'pipe'] });
const base = 'http://127.0.0.1:' + port;
try {
  let online = false;
  for (let attempt = 0; attempt < 80; attempt++) {
    try { online = (await fetch(base + '/health', { headers: { Authorization: 'Bearer ' + secret } })).ok; } catch {}
    if (online) break;
    await new Promise(resolve => setTimeout(resolve, 50));
  }
  assert.ok(online, 'Engine started');
  check((await fetch(base + '/health')).status, 401, 'Private engine rejects unauthenticated access');
  check((await(await fetch(base+'/health',{headers:{Authorization:'Bearer '+secret}})).json()).protocol,5,'The staged engine advertises protocol5');
  const generate = async body => {
    const response = await fetch(base + '/generate', { method: 'POST', headers: { Authorization: 'Bearer ' + secret, 'Content-Type': 'application/json' }, body: JSON.stringify({ ticket: 'fixture-request-scope', files: {}, messages: [{ id: 'user', role: 'user', content: 'أنشئ قائمة عناصر' }], ...body }) });
    const events=(await response.text()).trim().split('\n').filter(line=>line.trim()).map(line => JSON.parse(line));
    lastActivity=events.filter(event=>event.type==='activity');
    return events.filter(event=>event.type!=='activity');
  };
  const planning = await generate({ mode: 'planning' });
  check(planning[0].plan.kind, 'questions', 'Ambiguous brief asks questions before file generation');
  check(planning.some(e => e.type === 'files'), false, 'Planning cannot release source files');
  check(planning[0].plan.questions.map(q => q.multiple), [false, true], 'Question cards preserve single and multiple selection intent');
  mode = 'planning_answers';
  const answered = await generate({mode:'planning', messages:[
    {role:'user',content:'أريد موقعًا شخصيًا'},
    {role:'assistant',content:questionPlan.message,plan:questionPlan},
    {role:'user',content:'ما هدف الموقع؟: موقع شخصي\nما الميزات المطلوبة؟: حجز، تواصل'},
  ]});
  check(answered[0].plan.kind, 'proposal', 'Combined answers and full question history lead to a reviewable proposal');
  check(answered.some(e => e.type === 'files'), false, 'Answering the questionnaire does not approve execution');
  mode = 'planning_wrapped';
  const wrapped = await generate({mode:'planning'});
  check(wrapped[0].plan.kind, 'proposal', 'Planning accepts complete JSON with prose, fences and trailing commas');
  mode = 'planning_repair'; planningAttempts = 0;
  const repaired = await generate({mode:'planning'});
  check(repaired[0].plan.kind, 'proposal', 'Schema correction receives the failed response and field errors');
  check(planningAttempts, 2, 'Format correction is bounded to one additional model request');
  for (const invalidMode of ['planning_invalid','planning_truncated','planning_ambiguous','planning_ambiguous_wrapped','planning_duplicate_options']) {
    mode = invalidMode;
    const failed = await generate({mode:'planning'});
    check(failed.at(-1).type, 'error', invalidMode + ' never becomes a proposal');
    check(failed.some(e=>e.type==='files'||e.type==='plan'), false, invalidMode + ' never starts execution');
  }
  mode = 'build'; calls.length = 0;
  const events = await generate({ mode: 'build', approvedPlan: { kind: 'proposal', title: 'Items', summary: 'Items app', pages: [{ name: 'Home', purpose: 'Manage items' }], features: ['Save items'], design: 'Arabic form', assumptions: [], steps: ['Implement'], acceptanceChecks: criteria } });
  const result = events.find(e => e.type === 'files');
  check(calls, ['file_planner','builder','builder','builder','file_reviewer','file_reviewer','file_reviewer'], 'File tree, content and actual review execute in order');
  check(Object.keys(result.files).length, Object.keys(source).length, 'Direct result contains every requested source file');
  check(result.annotation.type, 'studioReviewedBuild', 'Completion records reviewed source');
  const pipeline=events.filter(e=>e.type==='pipeline');
  check(Object.values(pipeline.find(e=>e.stage==='structure'&&e.files).files).every(file=>file.content===''),true,'The file tree precedes content');
  check(pipeline.at(-1).stage,'reviewing','The final source was reviewed');
  check(pipeline.at(-1).completed,pipeline.at(-1).total,'Every editable source was reviewed');
  check(events.some(event=>event.type==='agents'),false,'No agent stages are sent to the platform');
  check(events.at(-1).type, 'done', 'Completion has an explicit terminal event');
  check(lastActivity.filter(event=>event.phase==='waiting_provider').length,7,'Every model call reports waiting before source generation');
  check(lastActivity.some(event=>event.phase==='receiving'&&event.chars>0),true,'Actual received source produces observable character progress');
  check(lastActivity.at(-1).phase,'validating','A complete model reply enters format validation');
  mode='build_json';
  const jsonEvents=await generate({mode:'build',approvedPlan:proposal});
  check(jsonEvents.at(-1).type,'done','Canonical JSON file output completes through the actual HTTP engine');
  const exact=jsonEvents.find(event=>event.type==='files');
  check(exact.files['/home/project/server.mjs'].content,source['server.mjs'],'Source bytes survive the engine final serialization');
  mode='build_recovery';calls.length=0;coderFailures=0;
  const recovered=await generate({mode:'build',approvedPlan:{...proposal,acceptanceChecks:criteria}});
  check(calls.filter(role=>role==='builder').length,4,'A format correction retries only the failed writing call');
  check(recovered.at(-1).type,'done','Concrete format feedback repairs the response without a review report');
  check(recovered.find(event=>event.type==='files').files['/home/project/server.test.mjs'].content,source['server.test.mjs'],'Recovery preserves meaningful project tests');
  mode='build_bad';
  const invalid=await generate({mode:'build',approvedPlan:proposal});
  check(invalid.at(-1).code,'file_format','Failed format correction keeps a machine-readable error code');
  check(invalid.filter(event=>event.type==='validation').length,3,'Every rejected format retains a bounded validation reason');
  check(invalid.at(-1).message.includes('DF_CHAT_ERROR'),false,'The user sees a readable error, never the internal protocol');
  check(invalid.some(event=>event.type==='files'||event.type==='done'),false,'Invalid agent output never releases files or success');
  mode='build_stream';
  const streamed=await generate({mode:'build',approvedPlan:proposal});
  check(streamed.at(-1).type,'done','Incremental NDJSON bridge completes across one-byte UTF-8 and CRLF boundaries');
  check(streamed.find(event=>event.type==='files').files['/home/project/server.mjs'].content,source['server.mjs'],'Streaming preserves every source byte');
  mode='repair_focus';requests.length=0;
  const manyFiles={};
  for(let index=0;index<30;index++)manyFiles['/home/project/a'+index+'.js']={type:'file',content:'// filler '+index+'\n'+'x'.repeat(900),isBinary:false};
  manyFiles['/home/project/z-broken.js']={type:'file',content:'export const broken = "IMPORTANT_DIAGNOSTIC_SOURCE";\n//'+'z'.repeat(2400),isBinary:false};
  const focused=await generate({mode:'build',approvedPlan:proposal,contextLength:8192,files:manyFiles,repairContext:{step:'types',diagnostic:'An exported value failed type checking',affectedFiles:['/home/project/z-broken.js'],automatic:true}});
  check(requests[0].messages[0].content.includes('IMPORTANT_DIAGNOSTIC_SOURCE'),true,'Explicit affected source reaches planner beyond cutoff');
  check(focused.at(-1).type,'done','Repair and review complete within an8K context');
  check(requests.every(request=>request.messages.reduce((sum,message)=>sum+message.content.length+16,0)<12000),true,'Review prompts respect the small context budget');
  const folder = await mkdtemp(join(tmpdir(), 'rsvx7-builder-test-'));
  try {
    for (const [path, file] of Object.entries(result.files)) {
      const target = join(folder, path.replace('/home/project/', '')); await mkdir(join(target, '..'), { recursive: true }); await writeFile(target, file.content);
    }
    const output = await new Promise((resolve, reject) => execFile(process.execPath, ['--test', '--test-reporter=tap', 'server.test.mjs'], { cwd: folder, timeout: 20000 }, (error, stdout) => error ? reject(error) : resolve(stdout)));
    check(output.includes('# fail 0'), true, 'Generated fixture executes actual HTTP and persistence tests');
  } finally { await rm(folder, { recursive: true, force: true }); }
  console.log(`Builder engine checks passed: ${checks}. Model replies are fixtures.`);
} finally {
  engine.kill(); await once(engine, 'exit'); await new Promise(resolve => mock.close(resolve));
}
