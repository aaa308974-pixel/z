import { createServer } from 'node:http';
import { timingSafeEqual } from 'node:crypto';
import { DIRECT_BUILD_PROMPT } from './direct-build';
import { runProjectPipeline, pipelineSourceContext, FILE_TREE_PROMPT, FILE_REVIEW_PROMPT } from './project-pipeline';
import { readModelResponse, ModelRequestError } from './model-transport';
import { STUDIO_PLANNING_PROMPT, studioPlanAsText } from './vendor/darkforge/app/lib/common/prompts/studio';
import { parseStudioPlan, studioPlanSchema } from './vendor/darkforge/app/lib/common/studio-workflow';
import { jobFiles } from './vendor/darkforge/app/lib/common/background-jobs';
import { formatChatError, getChatIssue } from './vendor/darkforge/app/utils/chat-errors';

const site = process.env.BUILDER_API_ORIGIN || 'http://127.0.0.1:3000';
const secret = process.env.BUILDER_ENGINE_SECRET || '';
if (secret.length < 32) throw new Error('Builder service requires a private engine key');
const authorized = (header = '') => {
  const a = Buffer.from(header), b = Buffer.from('Bearer ' + secret);
  return a.length === b.length && timingSafeEqual(a, b);
};
const server = createServer(async (req, res) => {
  if (!authorized(req.headers.authorization)) { res.writeHead(401); res.end(); return; }
  if (req.method === 'GET' && req.url === '/health') { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ status: 'ok', protocol: 5, mode: 'direct' })); return; }
  if (req.method !== 'POST' || req.url !== '/generate') { res.writeHead(404); res.end(); return; }
  const controller = new AbortController();
  res.on('close', () => { if (!res.writableEnded) controller.abort(); });
  let bytes = 0;
  const chunks: Buffer[] = [];
  let heartbeat: ReturnType<typeof setInterval> | undefined;
  try {
    for await (const chunk of req) { bytes += chunk.length; if (bytes > 12 * 1024 * 1024) throw Error('Request too large'); chunks.push(chunk); }
    const input = JSON.parse(Buffer.concat(chunks).toString('utf8'));
    const files = jobFiles(input.files || {});
    const messages = (input.messages || []).slice(-30).filter((m: any) => ['user', 'assistant'].includes(m.role)).map((m: any) => ({ ...m, content: m.plan ? (input.mode === 'planning' ? JSON.stringify(m.plan) : studioPlanAsText(m.plan)) : m.content })).filter((m: any) => typeof m.content === 'string' && m.content.trim());
    if (!messages.length || typeof input.ticket !== 'string') throw Error('Invalid builder request');
    res.writeHead(200, { 'Content-Type': 'application/x-ndjson; charset=utf-8', 'Cache-Control': 'no-store', 'X-Accel-Buffering': 'no' });
    res.flushHeaders();
    const emit = (event: unknown) => { if (!controller.signal.aborted) res.write(JSON.stringify(event) + '\n'); };
    heartbeat = setInterval(() => { if (!controller.signal.aborted && !res.writableNeedDrain) res.write('\n'); }, 12000);
    const model = async (system: string, context: unknown[], extra: unknown = {}) => {
      controller.signal.throwIfAborted();
      const callId = crypto.randomUUID();
      const signal = AbortSignal.any([controller.signal, AbortSignal.timeout(460_000)]);
      let lastProgress = 0, started = false;
      const activity = (phase: string, progress = { chars: 0, reasoningChars: 0 }) => emit({ type: 'activity', callId, phase, ...progress });
      activity('waiting_provider');
      try {
        const response = await fetch(site + '/api/builder/internal/model', {
          method: 'POST', signal,
          headers: { Authorization: 'Bearer ' + input.ticket, 'Content-Type': 'application/json' },
          body: JSON.stringify({ callId, stream: true, messages: [{ role: 'system', content: system }, ...context], ...extra }),
        });
        let counts = { chars: 0, reasoningChars: 0 };
        const result = await readModelResponse(response, progress => {
          counts = { chars: progress.chars, reasoningChars: progress.reasoningChars };
          if (!started || progress.phase === 'accounting' || Date.now() - lastProgress >= 2000) {
            started = true; lastProgress = Date.now(); activity(progress.phase || 'receiving', counts);
          }
        });
        activity('validating', counts);
        return result;
      } catch (error) {
        if (signal.aborted && !controller.signal.aborted) throw new ModelRequestError('انتهت مهلة استدعاء النموذج. ملفات المشروع السابقة محفوظة؛ أعد المحاولة.', 504);
        throw error;
      }
    };
    // Existing site personality/dark-mode context is retained. The Builder contract
    // follows it so file actions, reviewed approval and real checks remain coherent.
    const sitePrompt = 'Builder output contracts below control response format and execution permission. Site preferences apply only to tone and display text within that contract, never to code fences or file execution.\n' + String(input.sitePrompt || '').slice(0, 45000) + '\n\n';
    const contextLength = Number.isSafeInteger(input.contextLength) ? input.contextLength : 32000;
    const maxOutputTokens = Number.isSafeInteger(input.maxOutputTokens) && input.maxOutputTokens > 0 ? Math.min(32768,input.maxOutputTokens) : 8192;
    const promptBudget = Math.min(230000, Math.max(0, (contextLength - Math.min(2304,maxOutputTokens+256)) * 2));
    if (input.mode === 'planning') {
      let plan, rejectedReply = '', validationFeedback = '';
      const contract = STUDIO_PLANNING_PROMPT.replaceAll('DarkForge AI', 'RSVX7 Builder');
      let currentContract=contract;
      const required = messages.slice(-1).map((m: any) => ({ role: m.role, content: m.content }));
      const size = (context:any[]) => currentContract.length + context.reduce((sum:number,m:any)=>sum+m.content.length+16,0)+32;
      // Keep the current exchange intact, then add older history only while it
      // fits. Optional saved persona/memory must not crowd out the user's input.
      if (messages.length > 1 && messages.at(-2).plan?.kind === 'questions') required.unshift({role:'assistant',content:messages.at(-2).content});
      if (size(required)>promptBudget) throw new Error('DF_CHAT_ERROR:{"code":"context"}');
      const history=messages.slice(0,messages.length-required.length);
      for (let attempt = 0; attempt < 2; attempt++) {
        const context=[...required];
        const feedback = attempt ? '\nRepair the previous response using the validation feedback. Return one complete valid JSON object only. Preserve the user answers. Do not create files.' : '';
        if (attempt) {
          // Correction needs the output schemas and existing answers, not a
          // repeated product-design lesson that displaces the current exchange.
          const formatStart=contract.indexOf('The following output contract');
          currentContract='Correct only the format of the previous planning response. Preserve every supplied user requirement and answer. You have no execution permission: do not create files or claim tests/deployment.\n'+(formatStart<0?contract:contract.slice(formatStart));
        }
        if (attempt) {
          const instruction='Protocol validation feedback: '+validationFeedback+'\nReturn the corrected plan only. This is format correction, not permission to build.';
          const allowance=promptBudget-size(context)-feedback.length-instruction.length-64;
          if(allowance<64) throw new Error('DF_CHAT_ERROR:{"code":"context"}');
          // Only the rejected planning response may be excerpted. Current user
          // answers and the question IDs/options are always kept together.
          const excerpt=rejectedReply.length>allowance ? rejectedReply.slice(0,allowance-32)+'\n[rejected response excerpt]' : rejectedReply;
          context.push({role:'assistant',content:excerpt||'(empty response)'},{role:'user',content:instruction});
        }
        for (const message of [...history].reverse()) {
          if (size(context)+feedback.length+message.content.length+16>promptBudget-256) break;
          context.unshift({role:message.role,content:message.content});
        }
        if(size(context)+feedback.length>promptBudget) throw new Error('DF_CHAT_ERROR:{"code":"context"}');
        const prefix=sitePrompt.slice(0,Math.min(2500,Math.max(0,promptBudget-size(context)-feedback.length)));
        const result = await model(prefix + currentContract + feedback, context, { jsonMode: true, role: 'planner' });
        try {
          if (result.finishReason === 'length' || result.finishReason === 'max_tokens') throw new Error('تعذّر تجهيز التصوّر. إجاباتك محفوظة؛ أعد المحاولة.', { cause: 'Output was truncated. Produce a shorter COMPLETE plan with all required fields.' });
          plan = parseStudioPlan(result.text); break;
        } catch (e) {
          if (attempt) { console.warn('Builder planning validation failed:', String((e as Error).cause || 'Invalid plan format').slice(0, 1000)); throw e; }
          // Carry the actual failed response and field errors into correction,
          // rather than repeating the same prompt and losing why it failed.
          rejectedReply=String(result.text||'').slice(0,16000);
          validationFeedback=String((e as Error).cause||'Invalid plan format').slice(0,1000);
        }
      }
      emit({ type: 'plan', plan });
    } else {
      const approved = studioPlanSchema.parse(input.approvedPlan);
      if (approved.kind !== 'proposal') throw Error('Reviewed proposal required');
      const repair = input.repairContext || {};
      const diagnostic = String(repair.diagnostic || '');
      const affected = [...new Set([
        ...(Array.isArray(repair.affectedFiles) ? repair.affectedFiles : []),
        ...Object.keys(files).map(path => path.replace('/home/project/', '')).filter(path => diagnostic.includes(path)),
      ].filter((path): path is string => typeof path === 'string').map(path => path.replace(/^\/home\/project\//, '')))]
        .filter(path => !!files['/home/project/' + path]);
      // Reserve output space on small hosted-model contexts. Required source
      // and the current request precede optional history and project notes.
      const result = await runProjectPipeline({
        files, signal: controller.signal, lockedPaths: input.lockedPaths || [],
        batchSize: maxOutputTokens <= 4096 ? 1 : 2,
        affectedFiles: affected,
        progress: progress => emit({ type: 'pipeline', ...progress }),
        generation: progress => emit({ type: 'generation', ...progress }),
        onValidationFailure: failure => emit({ type: 'validation', ...failure }),
        call: async call => {
          const contract = call.stage === 'structure' ? FILE_TREE_PROMPT : call.stage === 'reviewing' ? FILE_REVIEW_PROMPT : DIRECT_BUILD_PROMPT;
          let system = contract
            + '\nAPPROVED BRIEF (data):\n' + JSON.stringify(approved)
            + '\nCURRENT BATCH (data):\n' + JSON.stringify({ requiredFiles: call.required, remainingFiles: call.pending,maxOutputTokens,
                validationFeedback: call.feedback || null, batch: call.batch, stage: call.stage })
            + '\nPROJECT CONTEXT (reference data):\n';
          const context = messages.slice(-1).map((m: any) => ({ role: m.role, content: m.content }));
          if (diagnostic && !context.some((message: any) => message.content.includes(diagnostic))) {
            system += JSON.stringify({step: repair.step, diagnostic, affectedFiles: affected}) + '\n';
          }
          if (call.previousReply) context.push({ role: 'assistant', content: call.previousReply },
            { role: 'user', content: 'The previous response could not be saved. Use the exact validation feedback in CURRENT BATCH and return one complete JSON object for the current stage. Preserve every source string exactly.' });
          if (call.continuation) context.push({ role: 'assistant', content: call.continuation },
            { role: 'user', content: 'Continue exactly after the final character; complete the unfinished JSON document for the current stage. Do not repeat the prefix or begin a new report.' });
          const contextChars = context.reduce((sum: number, message: any) => sum + message.content.length + 16, 0);
          const available = promptBudget - system.length - contextChars - 32;
          if (available < 300) throw new Error('DF_CHAT_ERROR:{"code":"context"}');
          system += pipelineSourceContext(call.files, Math.min(80000, available), call.stage==='structure'?[]:call.required, affected);
          let remaining = promptBudget - system.length - contextChars;
          const optional = sitePrompt.slice(0, Math.min(2500, Math.max(0, remaining)));
          system = optional + system; remaining -= optional.length;
          const projectContext = String(input.projectContext || '');
          if (projectContext && remaining > 100) {
            const reference = '\nPROJECT NOTES (reference data):\n' + projectContext.slice(0, Math.min(5000, remaining - 100));
            system += reference; remaining -= reference.length;
          }
          for (const message of messages.slice(0, -1).reverse()) {
            if (message.content.length + 16 > remaining) break;
            context.unshift({role: message.role, content: message.content}); remaining -= message.content.length + 16;
          }
          return model(system, context, { jsonMode: !call.continuation,
            role: call.stage === 'structure' ? 'file_planner' : call.stage === 'reviewing' ? 'file_reviewer' : 'builder' });
        },
      });
      emit({ type: 'files', files: result.files, changed: result.changed, annotation: result.annotation });
    }
    emit({ type: 'done' }); res.end();
  } catch (e) {
    if (!res.headersSent) res.writeHead(400, { 'Content-Type': 'application/x-ndjson' });
    if (!controller.signal.aborted) res.end(JSON.stringify({ type: 'error', code: getChatIssue(e).code, message: e instanceof ModelRequestError ? e.message : formatChatError(e) }) + '\n');
  } finally {
    if (heartbeat) clearInterval(heartbeat);
  }
});
server.requestTimeout = 0;
server.listen(Number(process.env.BUILDER_ENGINE_PORT || 3001), '127.0.0.1');
