/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  content: ["./src/**/*.{js,jsx,ts,tsx}", "./public/index.html"],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Manrope', 'Noto Sans Arabic', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        heading: ['Manrope', 'Noto Sans Arabic', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'ui-monospace', 'SFMono-Regular', 'Menlo', 'Consolas', 'monospace'],
      },
      borderRadius: {
        lg: 'var(--radius)',
        md: 'calc(var(--radius) - 2px)',
        sm: 'calc(var(--radius) - 4px)',
      },
      colors: {
        background: 'oklch(var(--background-channels) / <alpha-value>)',
        foreground: 'oklch(var(--foreground-channels) / <alpha-value>)',
        card: {
          DEFAULT: 'oklch(var(--card-channels) / <alpha-value>)',
          foreground: 'oklch(var(--foreground-channels) / <alpha-value>)',
        },
        popover: {
          DEFAULT: 'oklch(var(--popover-channels) / <alpha-value>)',
          foreground: 'oklch(var(--foreground-channels) / <alpha-value>)',
        },
        primary: {
          DEFAULT: 'oklch(var(--primary-channels) / <alpha-value>)',
          foreground: 'oklch(var(--primary-foreground-channels) / <alpha-value>)',
        },
        secondary: {
          DEFAULT: 'oklch(var(--secondary-channels) / <alpha-value>)',
          foreground: 'oklch(var(--secondary-foreground-channels) / <alpha-value>)',
        },
        muted: {
          DEFAULT: 'oklch(var(--muted-channels) / <alpha-value>)',
          foreground: 'oklch(var(--muted-foreground-channels) / <alpha-value>)',
        },
        accent: {
          DEFAULT: 'oklch(var(--accent-channels) / <alpha-value>)',
          foreground: 'oklch(var(--accent-foreground-channels) / <alpha-value>)',
        },
        destructive: {
          DEFAULT: 'oklch(var(--destructive-channels) / <alpha-value>)',
          foreground: 'oklch(var(--primary-foreground-channels) / <alpha-value>)',
        },
        border: 'oklch(var(--border-channels) / <alpha-value>)',
        input: 'oklch(var(--input-channels) / <alpha-value>)',
        ring: 'oklch(var(--primary-channels) / <alpha-value>)',
        brand: {
          200: 'oklch(var(--primary-channels) / <alpha-value>)',
          300: 'oklch(var(--primary-channels) / <alpha-value>)',
          400: 'oklch(var(--primary-channels) / <alpha-value>)',
          500: 'oklch(var(--primary-channels) / <alpha-value>)',
          600: 'oklch(var(--primary-channels) / <alpha-value>)',
          700: 'oklch(var(--primary-channels) / <alpha-value>)',
        },
        bg: {
          main: 'oklch(var(--background-channels) / <alpha-value>)',
          surface: 'oklch(var(--card-channels) / <alpha-value>)',
          surface2: 'oklch(var(--secondary-channels) / <alpha-value>)',
          deep: 'oklch(var(--background-channels) / <alpha-value>)',
        },
        zinc: { 400: 'oklch(var(--muted-foreground-channels) / <alpha-value>)', 500: 'oklch(var(--muted-foreground-channels) / <alpha-value>)' },
      },
      keyframes: {
        'accordion-down': { from: { height: '0' }, to: { height: 'var(--radix-accordion-content-height)' } },
        'accordion-up': { from: { height: 'var(--radix-accordion-content-height)' }, to: { height: '0' } },
        'fade-up': { '0%': { opacity: '0', transform: 'translateY(8px)' }, '100%': { opacity: '1', transform: 'translateY(0)' } },
        'pulse-glow': { '0%,100%': { boxShadow: '0 0 20px rgba(122,31,43,0.25)' }, '50%': { boxShadow: '0 0 32px rgba(177,58,74,0.5)' } },
        'shimmer': { '100%': { transform: 'translateX(100%)' } },
        'cursor-blink': { '0%,49%': { opacity: '1' }, '50%,100%': { opacity: '0' } },
      },
      animation: {
        'accordion-down': 'accordion-down 0.2s ease-out',
        'accordion-up': 'accordion-up 0.2s ease-out',
        'fade-up': 'fade-up 0.35s cubic-bezier(.21,1.02,.73,1) both',
        'pulse-glow': 'pulse-glow 2.4s ease-in-out infinite',
        'shimmer': 'shimmer 1.6s linear infinite',
        'cursor-blink': 'cursor-blink 1s steps(1) infinite',
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
};
