import { formatNumber, getDirection, setLanguage, translate } from "@/i18n";
import "@/i18n/catalogs/services";
import { suggestedTitle } from "@/lib/aiClient";
import { roleLabel } from "@/lib/roles";
import { formatTokens } from "@/context/TokensContext";

beforeEach(() => {
  localStorage.clear();
  setLanguage("ar");
});

afterEach(() => setLanguage("ar"));

test("services English catalog translates labels/placeholders without translating content", () => {
  setLanguage("en");

  expect(getDirection()).toBe("ltr");
  expect(translate("فشل الطلب ({status}).", { status: 409 }, "services")).toBe("Request failed (409).");
  expect(translate("رسالة API غير معروفة", {}, "services")).toBe("رسالة API غير معروفة");
  expect(suggestedTitle("")).toBe("New chat");
  expect(roleLabel("admin")).toBe("Admin");
  expect(formatNumber(1234)).toBe("1,234");
  expect(formatTokens(1234)).toBe("1,234");
});

test("Arabic remains the default and user content stays unchanged", () => {
  const userText = "نص يملكه المستخدم";

  expect(getDirection()).toBe("rtl");
  expect(translate("فشل الطلب ({status}).", { status: 409 }, "services")).toBe("فشل الطلب (409).");
  expect(suggestedTitle(userText)).toBe(userText);
  expect(roleLabel("admin")).toBe("مسؤول");

  setLanguage("en");
  expect(suggestedTitle(userText)).toBe(userText);
});
