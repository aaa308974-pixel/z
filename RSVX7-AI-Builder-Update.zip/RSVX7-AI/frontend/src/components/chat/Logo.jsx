import React from "react";

export default function Logo({ size = 32, className = "" }) {
  return <span className={`inline-flex items-center justify-center ${className}`} style={{ width:size, height:size, color:"var(--primary)" }} data-testid="brand-logo">
    <svg viewBox="0 0 24 24" fill="none" width={size} height={size} aria-hidden="true">
      <path d="M4 7 L12 3 L20 7 L20 17 L12 21 L4 17 Z" stroke="currentColor" strokeWidth="1.1" strokeLinejoin="round" />
      <path d="M6 8 L12 5 L18 8 L18 16 L12 19 L6 16 Z" stroke="currentColor" strokeWidth=".7" opacity=".45" />
      <path d="M8 10 L12 12 L16 10 M12 12 L12 17" stroke="currentColor" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  </span>;
}
