import React, { useMemo, useRef, useState } from "react";
import {
  BrainCircuit, ChevronsUpDown, Code2, Cog, Download, Folder, FolderKanban,
  LayoutDashboard, LogOut, MessageSquare, MoreHorizontal, PanelLeftClose,
  PanelLeftOpen, Pencil, Pin, PinOff, Plus, Search, Settings, ShieldCheck,
  Trash2, Upload,
} from "lucide-react";
import Logo from "@/components/chat/Logo";
import { useChat } from "@/context/ChatContext";
import { useWorkspace } from "@/context/WorkspaceContext";
import { useBuilderProjects } from "@/builder/BuilderProjectsContext";
import BuilderProjectList from "@/builder/BuilderProjectList";
import ProjectSwitcher, { ProjectIcon } from "@/components/workspace/ProjectSwitcher";
import ProjectSettingsDialog from "@/components/workspace/ProjectSettingsDialog";
import GlobalSearchDialog from "@/components/workspace/GlobalSearchDialog";
import { TokenBalanceChip } from "@/components/chat/TokenBalance";
import { MODELS, DEFAULT_MODEL_ID } from "@/components/chat/ModelPicker";
import { isAdmin } from "@/lib/roles";
import { Input } from "@/components/ui/input";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { useI18n } from "@/i18n";
import "@/i18n/catalogs/chat";

function ChatRow({ chat, active, onClick, onAction }) {
  const { t } = useI18n("chat");
  const [editing, setEditing] = useState(false);
  const [title, setTitle] = useState(chat.title);
  const model = chat.messages?.length ? MODELS.find((item) => item.id === (chat.modelId || DEFAULT_MODEL_ID)) : null;
  const ModelIcon = model?.icon;
  const finishRename = () => {
    setEditing(false);
    const next = title.trim();
    if (next && next !== chat.title) onAction("rename", chat.id, next);
    else setTitle(chat.title);
  };
  return (
    <div onClick={() => !editing && onClick(chat.id)} data-testid={`chat-row-${chat.id}`} data-chat-item={chat.id} className={`chat-row ${active ? "is-active" : ""}`} role="button" tabIndex={0} onKeyDown={(event) => { if (event.key === "Enter" && !editing) onClick(chat.id); }}>
      <MessageSquare size={16} aria-hidden="true" />
      {editing ? <input autoFocus value={title} onChange={(event) => setTitle(event.target.value)} onBlur={finishRename} onKeyDown={(event) => { if (event.key === "Enter") event.currentTarget.blur(); if (event.key === "Escape") { setTitle(chat.title); setEditing(false); } }} className="chat-row-edit" data-testid={`chat-rename-input-${chat.id}`} aria-label={t("اسم المحادثة")} /> : <span className="chat-row-title" dir="auto">{chat.title}</span>}
      {model && <span data-testid={`chat-model-tag-${chat.id}`} className="chat-model-tag" title={t("النموذج: {model}", { model: model.label })}>{ModelIcon && <ModelIcon size={11} aria-hidden="true" />}{model.label}</span>}
      {chat.pinned && <Pin size={13} className="chat-pin" aria-label={t("مثبّتة")} />}
      <div className="chat-row-actions">
        <DropdownMenu>
          <DropdownMenuTrigger asChild><button onClick={(event) => event.stopPropagation()} className="chat-row-action" data-testid={`chat-menu-${chat.id}`} aria-label={t("إجراءات المحادثة")}><MoreHorizontal size={17} aria-hidden="true" /></button></DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="chat-popover chat-context-menu w-48 text-white">
            <DropdownMenuItem onClick={() => setEditing(true)} data-testid={`menu-rename-${chat.id}`}><Pencil size={15} />{t("إعادة التسمية")}</DropdownMenuItem>
            <DropdownMenuItem onClick={() => onAction("pin", chat.id)} data-testid={`menu-pin-${chat.id}`}>{chat.pinned ? <><PinOff size={15} />{t("إلغاء التثبيت")}</> : <><Pin size={15} />{t("تثبيت")}</>}</DropdownMenuItem>
            <DropdownMenuItem onClick={() => onAction("export", chat.id)} data-testid={`menu-export-${chat.id}`}><Download size={15} />{t("تصدير")}</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => onAction("delete", chat.id)} data-testid={`menu-delete-${chat.id}`} className="text-red-300 focus:text-red-200"><Trash2 size={15} />{t("حذف")}</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}

function ToolGroup({ icon: Icon, tone, label, hint, onClick, testId }) {
  return <button type="button" className={`chat-tool-group chat-tool-group-${tone}`} onClick={onClick} data-testid={testId}>
    <span className="chat-tool-icon"><Icon size={16} aria-hidden="true" /></span>
    <span className="chat-tool-copy"><strong>{label}</strong><small>{hint}</small></span>
    <span className="chat-tool-chevron" aria-hidden="true">›</span>
  </button>;
}

export default function Sidebar({ open, onToggle, onOpenSettings, onOpenDashboard, onOpenAdmin, onLogout, user, builderMode = false }) {
  const { t, dir } = useI18n("chat");
  const { chats, activeId, setActiveId, convLoading, createChat, deleteChat, renameChat, togglePin, exportChat, importChat } = useChat();
  const { currentProject } = useWorkspace();
  const builderProjects = useBuilderProjects();
  const closeOnMobile = () => { if (window.innerWidth < 768) onToggle(); };
  const newBuilderProject = () => builderProjects?.create().then(closeOnMobile).catch((error) => toast.error(error.message));
  const [projectsOpen, setProjectsOpen] = useState(false);
  const [projectSettingsOpen, setProjectSettingsOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const fileInputRef = useRef(null);
  const { pinned, others } = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    const visible = chats.filter((chat) => !normalized || chat.title.toLowerCase().includes(normalized));
    return { pinned: visible.filter((chat) => chat.pinned), others: visible.filter((chat) => !chat.pinned) };
  }, [chats, query]);
  const onAction = async (action, id, payload) => {
    if (action === "delete" && await deleteChat(id)) toast.success(t("تم حذف المحادثة"));
    if (action === "rename" && payload) renameChat(id, payload);
    if (action === "pin") togglePin(id);
    if (action === "export") { exportChat(id); toast.success(t("تم تصدير المحادثة")); }
  };
  const onImport = (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    importChat(file).then(() => toast.success(t("تم استيراد المحادثة"))).catch(() => toast.error(t("ملف محادثة غير صالح")));
    event.target.value = "";
  };
  return (
    <>
      <ProjectSwitcher open={projectsOpen} onClose={() => setProjectsOpen(false)} />
      <ProjectSettingsDialog open={projectSettingsOpen} project={currentProject} onClose={() => setProjectSettingsOpen(false)} />
      <GlobalSearchDialog open={searchOpen} onClose={() => setSearchOpen(false)} />
      <aside className={`chat-sidebar ${open ? "" : "is-closed"}`} data-testid="sidebar" aria-label={t("المشاريع والمحادثات")} dir={dir}>
        <div className="chat-sidebar-header">
          <div className="chat-brand-lockup"><Logo size={25} /><div><strong dir="ltr">rsvx7</strong><small>{t("مساعد متخصص في الأمن السيبراني واختبار الاختراق")}</small></div></div>
          <div className="chat-sidebar-controls"><button onClick={onToggle} className="chat-icon-button" data-testid="sidebar-collapse-btn" aria-label={t("طي الشريط الجانبي")}><PanelLeftClose size={17} aria-hidden="true" /></button></div>
        </div>
        <div className="chat-sidebar-tools">
          {builderMode
            ? <button onClick={newBuilderProject} data-testid="new-builder-project-btn" className="chat-new-chat" aria-label={t("مشروع Builder جديد")}><Plus size={16} aria-hidden="true" /><span>{t("مشروع Builder جديد")}</span></button>
            : <button onClick={() => { window.location.hash = "#chat"; createChat(); }} data-testid="new-chat-btn" className="chat-new-chat" aria-label={t("محادثة جديدة")}><Plus size={16} aria-hidden="true" /><span>{t("محادثة جديدة")}</span></button>}
          <div className="relative chat-history-search"><Search className="chat-search-icon" size={15} aria-hidden="true" /><Input value={query} onChange={(event) => setQuery(event.target.value)} placeholder={builderMode ? t("ابحث في مشاريع Builder") : t("ابحث في المحادثات")} data-testid="search-chats-input" className="chat-history-input" /></div>
          <div className="chat-tools-heading">{t("الأدوات")}</div>
          <div className="chat-tool-groups">
            <ToolGroup icon={Code2} tone="green" label="Hacker rsvx7 Ai" hint={t("تحكم SSH وAgent")} onClick={() => { window.location.hash = "#remote"; closeOnMobile(); }} testId="open-remote" />
            {builderMode
              ? <ToolGroup icon={MessageSquare} tone="pink" label={t("الدردشة")} hint={t("العودة إلى محادثاتك")} onClick={() => { window.location.hash = "#chat"; closeOnMobile(); }} testId="open-chat" />
              : <ToolGroup icon={Code2} tone="pink" label="Builder" hint={t("إنشاء المواقع والتطبيقات")} onClick={() => { window.location.hash = "#builder"; closeOnMobile(); }} testId="open-builder" />}
            <ToolGroup icon={FolderKanban} tone="green" label={t("المشاريع") } hint={currentProject?.name || t("ملفات ومساحات العمل")} onClick={() => setProjectsOpen(true)} testId="workspace-project-switcher" />
            <ToolGroup icon={BrainCircuit} tone="purple" label={t("الذاكرة والبحث") } hint={t("بحث داخل مشاريعك")} onClick={() => setSearchOpen(true)} testId="open-global-search" />
            <ToolGroup icon={Code2} tone="pink" label={t("مساعد الكود") } hint={t("مساعدة Hermes للكود")} onClick={() => setProjectSettingsOpen(true)} testId="open-project-settings" />
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild><button className="chat-tools-menu-trigger" data-testid="sidebar-tools-menu" aria-label={t("أدوات مساحة العمل")}><MoreHorizontal size={17} aria-hidden="true" />{t("خيارات مساحة العمل")}</button></DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="chat-popover chat-context-menu w-52 text-white">
              <DropdownMenuItem onClick={() => setSearchOpen(true)}><Search size={15} />{t("بحث في مساحة العمل")}</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setProjectsOpen(true)}><Folder size={15} />{t("المشاريع")}</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setProjectSettingsOpen(true)} disabled={!currentProject}><Cog size={15} />{t("إعدادات المشروع")}</DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onSelect={(event) => { event.preventDefault(); fileInputRef.current?.click(); }} data-testid="import-chat-menu"><Upload size={15} />{t("استيراد محادثة")}</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        <div className="chat-sidebar-list scroll-elegant">
          {builderMode ? <BuilderProjectList query={query} onOpened={closeOnMobile} /> : <>
          {convLoading && chats.length === 0 && <div className="chat-loading-skeleton" data-testid="chats-loading-skeleton">{[1, 2, 3, 4].map((item) => <div key={item} />)}</div>}
          {pinned.length > 0 && <><div className="chat-section-label">{t("مثبّتة")}</div>{pinned.map((chat) => <ChatRow key={chat.id} chat={chat} active={chat.id === activeId} onClick={setActiveId} onAction={onAction} />)}</>}
          <div className="chat-section-label">{t("محادثاتك")}</div>
          {others.length === 0 ? <div className="chat-empty-history"><Folder size={19} aria-hidden="true" />{t("لا توجد محادثات بعد")}</div> : others.map((chat) => <ChatRow key={chat.id} chat={chat} active={chat.id === activeId} onClick={setActiveId} onAction={onAction} />)}
          </>}
        </div>
        <div className="chat-sidebar-footer">
          <TokenBalanceChip />
          <div className="chat-balance-actions"><button type="button" onClick={onOpenDashboard} data-testid="footer-manage">{t("إدارة")}</button><button type="button" onClick={onOpenSettings} data-testid="footer-usage">{t("الاستخدام")}</button></div>
          <div className="chat-footer-row">
            <DropdownMenu>
              <DropdownMenuTrigger asChild><button className="chat-user-menu-trigger" data-testid="user-menu-btn" aria-label={t("فتح قائمة الحساب")}><span className="chat-user-avatar" aria-hidden="true">{(user?.username || "?").charAt(0)}</span><span className="chat-user-copy"><strong>{user?.username || t("الحساب")}</strong><small>{t("الحساب والإعدادات")}</small></span><ChevronsUpDown size={14} aria-hidden="true" /></button></DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="chat-popover chat-context-menu w-56 text-white"><div className="chat-account-name">{t("مسجّل باسم {name}", { name: user?.username || "" })}</div><DropdownMenuSeparator /><DropdownMenuItem onClick={onOpenDashboard} data-testid="menu-dashboard"><LayoutDashboard size={16} />{t("لوحة التحكم")}</DropdownMenuItem>{isAdmin(user) && <DropdownMenuItem onClick={onOpenAdmin} data-testid="menu-admin"><ShieldCheck size={16} />{t("لوحة الإدارة")}</DropdownMenuItem>}<DropdownMenuItem onClick={onOpenSettings} data-testid="menu-settings"><Settings size={16} />{t("الإعدادات")}</DropdownMenuItem><DropdownMenuSeparator /><DropdownMenuItem onClick={onLogout} data-testid="menu-logout" className="text-red-300 focus:text-red-200"><LogOut size={16} />{t("تسجيل الخروج")}</DropdownMenuItem></DropdownMenuContent>
            </DropdownMenu>
            <label className="chat-icon-button cursor-pointer" title={t("استيراد محادثة")} data-testid="import-chat-label"><Upload size={16} aria-hidden="true" /><input ref={fileInputRef} type="file" accept="application/json" className="hidden" onChange={onImport} data-testid="import-chat-input" /></label>
            <button onClick={onOpenSettings} data-testid="open-settings-btn" className="chat-icon-button" aria-label={t("فتح الإعدادات")} title={t("الإعدادات")}><Settings size={16} aria-hidden="true" /></button>
          </div>
        </div>
      </aside>
    </>
  );
}

export function SidebarOpenButton({ onClick }) {
  const { t } = useI18n("chat");
  return <button onClick={onClick} className="chat-icon-button" data-testid="sidebar-open-btn" aria-label={t("فتح الشريط الجانبي")}><PanelLeftOpen size={17} aria-hidden="true" /></button>;
}
