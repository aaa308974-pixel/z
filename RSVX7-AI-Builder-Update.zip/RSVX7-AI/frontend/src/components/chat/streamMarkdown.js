/**
 * Incremental Markdown scanner used while an assistant response is arriving.
 *
 * The scanner only consumes the newly appended suffix.  Completed prose blocks
 * and fenced code blocks are append-only, while the current line/block remains
 * in `tail` and is the only part that is reparsed by ReactMarkdown.
 */

const OPEN_FENCE_RE = /^[ \t]{0,3}(`{3,}|~{3,})([^\r\n]*)$/;
const HEADING_RE = /^[ \t]{0,3}#{1,6}(?:[ \t]+|$)/;
const THEMATIC_BREAK_RE = /^[ \t]{0,3}(?:(?:\*[ \t]*){3,}|(?:-[ \t]*){3,}|(?:_[ \t]*){3,})$/;
let nextPartKey = 0;

function newPartKey() {
  nextPartKey += 1;
  return `stream-part-${nextPartKey}`;
}

function withPartKey(part, key) {
  Object.defineProperty(part, "streamKey", {
    configurable: false,
    enumerable: false,
    value: key || newPartKey(),
  });
  return part;
}

function openingFence(line) {
  const match = OPEN_FENCE_RE.exec(line.replace(/\r$/, ""));
  if (!match) return null;
  const info = match[2].trim();
  return {
    character: match[1][0],
    length: match[1].length,
    language: info.split(/\s+/)[0] || "text",
  };
}

function closingFence(line, character, length) {
  const value = line.replace(/\r$/, "");
  const expression = new RegExp(`^[ \\t]{0,3}${character}{${length},}[ \\t]*$`);
  return expression.test(value);
}

function isCompleteTextLine(line) {
  const value = line.replace(/\r$/, "");
  return value.trim() === "" || HEADING_RE.test(value) || THEMATIC_BREAK_RE.test(value);
}

function appendSegment(state, segment, key = null) {
  if (segment.type === "text" && (!segment.value || !/\S/.test(segment.value))) return;
  if (!state.ownsSegments) {
    state.segments = state.segments.slice();
    state.ownsSegments = true;
  }
  state.segments.push(withPartKey(segment, key || state.tailKey));
  state.tailKey = null;
}

function flushText(state) {
  if (!state.textBuffer) return;
  appendSegment(state, { type: "text", value: state.textBuffer }, state.tailKey);
  state.textBuffer = "";
}

function finishCode(state) {
  const value = state.codeValue.replace(/\n$/, "");
  appendSegment(state, { type: "code", language: state.language, value }, state.tailKey);
  state.mode = "text";
  state.character = null;
  state.fenceLength = 0;
  state.language = "text";
  state.codeValue = "";
  state.lineBuffer = "";
  state.codeClosedAtEnd = false;
}

function consumeDelta(state, delta) {
  let offset = 0;
  while (offset < delta.length) {
    const newline = delta.indexOf("\n", offset);
    if (newline === -1) {
      state.lineBuffer += delta.slice(offset);
      break;
    }

    state.lineBuffer += delta.slice(offset, newline);
    const line = state.lineBuffer;
    state.lineBuffer = "";

    if (state.mode === "code") {
      if (closingFence(line, state.character, state.fenceLength)) {
        finishCode(state);
      } else {
        state.codeValue += `${line}\n`;
      }
    } else {
      const opening = openingFence(line);
      if (opening) {
        // The fence itself belongs to the structural scanner, not prose.
        flushText(state);
        state.mode = "code";
        state.character = opening.character;
        state.fenceLength = opening.length;
        state.language = opening.language;
        state.codeValue = "";
        state.codeClosedAtEnd = false;
      } else {
        state.textBuffer += `${line}\n`;
        if (isCompleteTextLine(line)) flushText(state);
      }
    }
    offset = newline + 1;
  }
}

function sameTail(a, b) {
  return Boolean(a && b && a.type === b.type && a.value === b.value && a.language === b.language && a.prefix === b.prefix && a.closed === b.closed);
}

function makeTail(state, previousTail, finalize) {
  let tail = null;
  if (state.mode === "code") {
    const candidate = closingFence(state.lineBuffer, state.character, state.fenceLength);
    if (finalize && candidate) {
      // A final response is allowed to end immediately after its closing
      // fence. Keep it as the same tail CodeBlock rather than moving it into a
      // new array entry during the live -> done transition.
      state.codeClosedAtEnd = true;
      tail = withPartKey({
        type: "code",
        language: state.language,
        value: state.codeValue.replace(/\n$/, ""),
        prefix: "",
        closed: true,
      }, state.tailKey);
    } else {
      const unresolved = candidate ? "" : state.lineBuffer;
      tail = withPartKey({
        type: "code",
        language: state.language,
        value: `${state.codeValue}${unresolved}`.replace(/\n$/, ""),
        prefix: "",
      }, state.tailKey);
    }
  } else {
    const value = state.textBuffer + state.lineBuffer;
    if (value) tail = withPartKey({ type: "text", value }, state.tailKey);
  }
  if (sameTail(previousTail, tail)) {
    state.tailKey = previousTail.streamKey;
    return previousTail;
  }
  state.tailKey = tail?.streamKey || null;
  return tail;
}

function initialState(text) {
  return {
    source: text,
    segments: [],
    ownsSegments: true,
    mode: "text",
    lineBuffer: "",
    textBuffer: "",
    codeValue: "",
    character: null,
    fenceLength: 0,
    language: "text",
    codeClosedAtEnd: false,
    tailKey: null,
    tail: null,
    cursor: 0,
  };
}

/**
 * Parse a cumulative stream snapshot without rescanning completed Markdown.
 * `finalize` is intentionally opt-in: the public parser remains conservative
 * about a closing fence at a chunk boundary, while Markdown uses it only when
 * the transport reports done.
 */
export function parseStreamMarkdown(source, previous = null, options = {}) {
  const text = String(source == null ? "" : source);
  const finalize = options === true || options?.finalize === true;
  const reusable = Boolean(previous && typeof previous.source === "string" && text.length >= previous.source.length && text.startsWith(previous.source));
  const state = reusable
    ? {
      ...previous,
      source: text,
      segments: previous.segments,
      ownsSegments: false,
      tail: previous.tail,
    }
    : initialState(text);

  const delta = reusable ? text.slice(previous.source.length) : text;
  // A previously finalized candidate is only possible when callers append to
  // a completed response. Treat that suffix as new code rather than dropping it.
  if (state.codeClosedAtEnd && delta) {
    state.codeClosedAtEnd = false;
    state.lineBuffer = "";
  }
  if (delta) consumeDelta(state, delta);

  state.tail = makeTail(state, reusable ? previous.tail : null, finalize);
  state.cursor = text.length;
  return state;
}
