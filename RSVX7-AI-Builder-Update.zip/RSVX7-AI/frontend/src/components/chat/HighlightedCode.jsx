import React from "react";
// Use the Light/lowlight entry rather than the Prism root: it keeps the
// highlighted chunk small and avoids importing every Prism grammar.
import SyntaxHighlighter from "react-syntax-highlighter/dist/cjs/light";
import javascript from "react-syntax-highlighter/dist/cjs/languages/hljs/javascript";
import typescript from "react-syntax-highlighter/dist/cjs/languages/hljs/typescript";
import python from "react-syntax-highlighter/dist/cjs/languages/hljs/python";
import json from "react-syntax-highlighter/dist/cjs/languages/hljs/json";
import xml from "react-syntax-highlighter/dist/cjs/languages/hljs/xml";
import css from "react-syntax-highlighter/dist/cjs/languages/hljs/css";
import bash from "react-syntax-highlighter/dist/cjs/languages/hljs/bash";

SyntaxHighlighter.registerLanguage("javascript", javascript);
SyntaxHighlighter.registerLanguage("typescript", typescript);
SyntaxHighlighter.registerLanguage("python", python);
SyntaxHighlighter.registerLanguage("json", json);
SyntaxHighlighter.registerLanguage("xml", xml);
SyntaxHighlighter.registerLanguage("markup", xml);
SyntaxHighlighter.registerLanguage("css", css);
SyntaxHighlighter.registerLanguage("bash", bash);

const LIGHT_HLJS = {
  hljs: { background: "transparent", color: "#d9dee7" },
  comment: { color: "#7f8998" }, keyword: { color: "#e0a3ba" },
  string: { color: "#b7d3bf" }, number: { color: "#d7a0b6" },
  title: { color: "#d7c58a" }, name: { color: "#e69bb0" },
  built_in: { color: "#d7c58a" }, type: { color: "#e69bb0" },
  meta: { color: "#b6c0cf" }, attr: { color: "#e69bb0" },
};

export default function HighlightedCode({ language, value, wrap }) {
  return <SyntaxHighlighter language={language} style={LIGHT_HLJS} wrapLongLines={wrap} showLineNumbers={false} customStyle={{ margin: 0, padding: "14px 16px", background: "transparent", fontSize: 13, lineHeight: 1.65, fontFamily: "'JetBrains Mono', ui-monospace, monospace", direction: "ltr", textAlign: "left" }} codeTagProps={{ dir: "ltr" }}>{value}</SyntaxHighlighter>;
}
