import React from "react";
import { act } from "react";
import { createRoot } from "react-dom/client";
import { setLanguage, t } from "@/i18n";
import WelcomeState from "./WelcomeState";
import FileChip from "./FileChip";
import CodeBlock from "./CodeBlock";
import Message from "./Message";

jest.mock("@/context/ChatContext", () => ({
  useChat: () => ({ regenerate: jest.fn(), editAndResend: jest.fn() }),
}));
jest.mock("react-markdown", () => ({ children }) => <div data-testid="mock-markdown">{children}</div>);
jest.mock("remark-gfm", () => () => null);

let container;
let root;

beforeEach(() => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  localStorage.clear();
  setLanguage("ar");
  container = document.createElement("div");
  document.body.appendChild(container);
  root = createRoot(container);
});

afterEach(async () => {
  await act(async () => root.unmount());
  setLanguage("ar");
  container.remove();
});

test("chat English translates static labels, uses ltr, and preserves dynamic content", async () => {
  setLanguage("en");
  await act(async () => root.render(<>
    <WelcomeState />
    <FileChip file={{ id: "file-1", name: "report.txt", size: 2048, status: "uploading" }} />
    <CodeBlock language="js" value="const answer = 42;" streaming />
    <Message message={{ id: "message-1", role: "user", content: "رسالة المستخدم لا تُترجم" }} />
  </>));

  expect(container.querySelector('[data-testid="welcome-state"]').getAttribute("dir")).toBe("ltr");
  expect(container.querySelector('[data-testid="welcome-greeting"]').textContent).toBe("Hello, I’m rsvx7");
  expect(container.textContent).toContain("Processing…");
  expect(container.textContent).toContain("report.txt");
  expect(container.querySelector('[data-testid="code-copy-btn"]').getAttribute("aria-label")).toBe("Copy code");
  expect(container.textContent).toContain("const answer = 42;");
  expect(container.textContent).toContain("رسالة المستخدم لا تُترجم");
  expect(container.querySelector('[data-testid="user-message-message-1"] .chat-user-bubble').getAttribute("dir")).toBe("auto");
});

test("chat English keeps dynamic placeholder values while translating the surrounding label", () => {
  setLanguage("en");
  expect(t("الحد الأقصى {count} ملفات", { count: 8 }, "chat")).toBe("Maximum 8 files");
  expect(t("{name}: مرفق (لا يتوفر استخراج نص)", { name: "report.txt" }, "chat")).toBe("report.txt: attached (no text extraction available)");
});
