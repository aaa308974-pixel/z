import React, { act } from "react";
import { createRoot } from "react-dom/client";
import MonthlyPricing from "./MonthlyPricing";
import AdminMemberships from "@/pages/AdminMemberships";
const mockAuth = { user: { _id: "alice", role: "user", entitlements: { plan: "free" } }, authFetch: jest.fn() };
jest.mock("@/context/AuthContext", () => ({ useAuth: () => mockAuth }));
const plans = [
  { id: "free", name: "Free", usd: 0, tokens: 10000 },
  { id: "pro", name: "Pro", usd: 25, tokens: 10000000 },
  { id: "max", name: "Max", usd: 50, tokens: 25000000 },
];
let host, root;
const reply = data => ({ ok: true, json: async () => data });
const lookup = id => host.querySelector(`[data-testid="${id}"]`);
beforeEach(() => {
  localStorage.clear(); mockAuth.authFetch.mockReset(); global.fetch = jest.fn(async () => reply({ plans }));
  host = document.createElement("div"); document.body.appendChild(host); root = createRoot(host);
  global.IS_REACT_ACT_ENVIRONMENT = true;
});
afterEach(async () => { await act(async () => root.unmount()); host.remove(); });
test("renders the three server-priced monthly cards and preserves extra credit copy", async () => {
  await act(async () => root.render(<MonthlyPricing wallet={{ plan: "free" }} />));
  for (const plan of plans) expect(lookup(`monthly-plan-${plan.id}`).textContent).toContain(`$${plan.usd}`);
  expect(lookup("monthly-plan-max").textContent).toContain("Hacker rsvx7 Ai");
  expect(lookup("monthly-plan-pro").textContent).toContain("Builder");
  expect(lookup("request-monthly-free").disabled).toBe(true);
});
test("requesting Max creates a pending request without activating or adding balance", async () => {
  mockAuth.authFetch.mockResolvedValue(reply({ request: { id: "pending-1", status: "pending" } }));
  await act(async () => root.render(<MonthlyPricing />));
  await act(async () => lookup("request-monthly-max").click());
  expect(mockAuth.authFetch).toHaveBeenCalledTimes(1);
  const [path, options] = mockAuth.authFetch.mock.calls[0];
  expect(path).toBe("/memberships/request"); expect(JSON.parse(options.body)).toEqual({ plan: "max" });
  expect(host.querySelector('[role="status"]').textContent).toContain("تأكيد الدفع");
});
test("failed requests show an error and allow a retry", async () => {
  mockAuth.authFetch.mockResolvedValue({ ok: false, json: async () => ({ detail: "تعذّر إرسال الطلب." }) });
  await act(async () => root.render(<MonthlyPricing />));
  await act(async () => lookup("request-monthly-pro").click());
  expect(host.querySelector('[role="alert"]')).not.toBeNull();
  expect(lookup("request-monthly-pro").disabled).toBe(false);
  expect(host.querySelector('[role="status"]')).toBeNull();
});
test("an uncertain admin activation reuses the same idempotency ID on retry", async () => {
  const member = { _id: "alice", username: "alice", role: "user", plan: "free", monthly_remaining: 10000, purchased_remaining: 333, request: { plan: "max", status: "pending" } };
  mockAuth.authFetch.mockImplementation(async (path, options) => options?.method === "POST" ? Promise.reject(Error("connection lost")) : reply({ users: [member], plans }));
  await act(async () => root.render(<AdminMemberships />));
  await act(async () => new Promise(resolve => setTimeout(resolve, 250)));
  const button = [...host.querySelectorAll("button")].find(node => node.textContent.includes("تفعيل شهر"));
  expect(button).toBeDefined();
  await act(async () => button.click()); await act(async () => button.click());
  const posts = mockAuth.authFetch.mock.calls.filter(([, options]) => options?.method === "POST");
  expect(posts).toHaveLength(2);
  const first = JSON.parse(posts[0][1].body), second = JSON.parse(posts[1][1].body);
  expect(first.plan).toBe("max"); expect(first.request_id).toBe(second.request_id);
  expect(host.textContent).toContain("connection lost");
});
