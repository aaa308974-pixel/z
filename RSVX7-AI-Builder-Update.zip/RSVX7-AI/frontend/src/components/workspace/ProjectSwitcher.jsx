import React, { useEffect, useMemo, useRef, useState } from "react";
import { useWorkspace } from "@/context/WorkspaceContext";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  Folder, FolderPlus, Star, Archive, ArchiveRestore, MoreHorizontal,
  Trash2, Pencil, Search, Check, MessageSquare, Sparkles, Code2, Beaker,
  BookOpen, Rocket, Bot, Palette, Music, Camera, GraduationCap, Briefcase,
} from "lucide-react";
import { ActionButton, StatusNote } from "@/components/design/Primitives";
import { useI18n } from "@/i18n";
import "@/i18n/catalogs/workspace";
import { toast } from "sonner";
import "./workspace-ui.css";

export const PROJECT_ICONS = {
  Sparkles, MessageSquare, Code2, Beaker, BookOpen, Rocket, Bot,
  Palette, Music, Camera, GraduationCap, Briefcase, Folder,
};

export const PROJECT_COLORS = [
  "var(--workspace-brand)", "var(--workspace-brand-soft)", "var(--workspace-brand-strong)",
  "color-mix(in oklch, var(--workspace-brand) 72%, var(--workspace-fg))",
  "color-mix(in oklch, var(--workspace-brand) 58%, var(--workspace-bg))",
  "color-mix(in oklch, var(--workspace-brand) 44%, var(--workspace-fg))",
  "color-mix(in oklch, var(--workspace-brand) 34%, var(--workspace-bg))",
  "color-mix(in oklch, var(--workspace-brand) 26%, var(--workspace-fg))",
  "var(--workspace-muted-fg)", "var(--workspace-fg)",
];
export const PROJECT_COLOR_TEST_IDS = ["9D3E59", "E69BB0", "E4572E", "F9C74F", "5DAB6F", "3D8ECC", "7A6FDB", "B24BF3", "556677", "0F172A"];
export const WORKSPACE_BRAND_COLOR = "var(--workspace-brand)";

export function ProjectIcon({ name, className }) {
  const Icon = PROJECT_ICONS[name] || Folder;
  return <Icon className={className} strokeWidth={1.7} aria-hidden="true" />;
}

function EditProjectDialog({ open, project, onClose }) {
  const { createProject, updateProject } = useWorkspace();
  const { t, dir } = useI18n("workspace");
  const isNew = !project;
  const [form, setForm] = useState({
    name: project?.name || "",
    description: project?.description || "",
    icon: project?.icon || "Sparkles",
    color: project?.color || PROJECT_COLORS[0],
    is_favorite: Boolean(project?.is_favorite),
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!open) return;
    setForm({
      name: project?.name || "",
      description: project?.description || "",
      icon: project?.icon || "Sparkles",
      color: project?.color || PROJECT_COLORS[0],
      is_favorite: Boolean(project?.is_favorite),
    });
    setError(null);
  }, [open, project]);

  const save = async () => {
    const name = form.name.trim();
    if (!name) { setError("اكتب اسمًا للمشروع أولًا."); return; }
    setSaving(true);
    setError(null);
    try {
      const payload = { ...form, name };
      if (isNew) {
        await createProject(payload);
        toast.success(t("تم إنشاء المشروع"));
      } else {
        await updateProject(project._id, payload);
        toast.success(t("تم حفظ تغييرات المشروع"));
      }
      onClose();
    } catch (e) {
      setError(e?.message || "تعذر حفظ المشروع.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(value) => !value && onClose()}>
      <DialogContent className="workspace-dialog workspace-edit-dialog" dir={dir} data-testid="edit-project-dialog">
        <DialogHeader>
          <p className="workspace-kicker">{t("مساحة العمل")}</p>
          <DialogTitle className="workspace-dialog-title">
            <FolderPlus aria-hidden="true" /> {isNew ? t("مشروع جديد") : t("تعديل المشروع")}
          </DialogTitle>
          <DialogDescription className="workspace-dialog-description">
            {isNew ? t("اجمع المحادثات والملفات والذاكرة في سياق واحد.") : t("حدّث هوية المشروع دون تغيير محتواه.")}
          </DialogDescription>
        </DialogHeader>

        <div className="workspace-form-stack">
          {error && <StatusNote tone="error">{t(error)}</StatusNote>}
          <label className="ds-field">
            <span className="ds-label">{t("اسم المشروع")}</span>
            <Input
              value={form.name}
              onChange={(event) => setForm((previous) => ({ ...previous, name: event.target.value }))}
              placeholder={t("مثل: موقع العميل")}
              data-testid="project-name-input"
              maxLength={80}
              autoFocus
              className="ds-input"
              dir="auto"
            />
          </label>

          <label className="ds-field">
            <span className="ds-label">{t("وصف مختصر")} <span className="workspace-muted">({t("اختياري")})</span></span>
            <Textarea
              value={form.description}
              onChange={(event) => setForm((previous) => ({ ...previous, description: event.target.value }))}
              placeholder={t("ما الذي يخص هذا المشروع؟")}
              data-testid="project-description-input"
              rows={2}
              maxLength={240}
              className="ds-textarea"
              dir="auto"
            />
          </label>

          <fieldset className="workspace-fieldset">
            <legend className="ds-label">{t("الأيقونة")}</legend>
            <div className="workspace-icon-grid">
              {Object.keys(PROJECT_ICONS).map((name) => {
                const active = form.icon === name;
                return (
                  <button
                    type="button"
                    key={name}
                    onClick={() => setForm((previous) => ({ ...previous, icon: name }))}
                    data-testid={`icon-${name}`}
                    className={`workspace-icon-choice${active ? " is-active" : ""}`}
                    aria-label={t("أيقونة {name}", { name })}
                    aria-pressed={active}
                  >
                    <ProjectIcon name={name} />
                  </button>
                );
              })}
            </div>
          </fieldset>

          <fieldset className="workspace-fieldset">
            <legend className="ds-label">{t("اللون")}</legend>
            <div className="workspace-color-grid">
              {PROJECT_COLORS.map((color, index) => (
                <button
                  type="button"
                  key={color}
                  onClick={() => setForm((previous) => ({ ...previous, color }))}
                  data-testid={`color-${PROJECT_COLOR_TEST_IDS[index]}`}
                  className={`workspace-color-choice${form.color === color ? " is-active" : ""}`}
                  style={{ "--swatch": color }}
                  aria-label={t("اللون {color}", { color })}
                  aria-pressed={form.color === color}
                />
              ))}
            </div>
          </fieldset>

          <label className="workspace-check-row">
            <input
              type="checkbox"
              checked={form.is_favorite}
              onChange={(event) => setForm((previous) => ({ ...previous, is_favorite: event.target.checked }))}
              data-testid="project-favorite-toggle"
            />
            <Star aria-hidden="true" className={form.is_favorite ? "is-favorite" : ""} />
            <span>{t("إضافة إلى المفضلة")}</span>
          </label>
        </div>

        <DialogFooter className="workspace-dialog-footer">
          <ActionButton tone="ghost" onClick={onClose}>{t("إلغاء")}</ActionButton>
          <ActionButton onClick={save} loading={saving} data-testid="save-project-btn">
            {isNew ? t("إنشاء المشروع") : t("حفظ التغييرات")}
          </ActionButton>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export default function ProjectSwitcher({ open, onClose }) {
  const {
    projects, archivedProjects, currentProjectId,
    setCurrentProjectId, updateProject, deleteProject, touchProjectOpened,
  } = useWorkspace();
  const { t, dir, formatNumber } = useI18n("workspace");
  const [query, setQuery] = useState("");
  const [editOpen, setEditOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [showArchived, setShowArchived] = useState(false);
  const [highlightedId, setHighlightedId] = useState(null);
  const searchRef = useRef(null);

  const list = showArchived ? archivedProjects : projects;
  const { favorites, others, filtered } = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase();
    const filteredProjects = (list || []).filter((project) => {
      const haystack = `${project.name || ""} ${project.description || ""}`.toLocaleLowerCase();
      return !normalized || haystack.includes(normalized);
    });
    return {
      filtered: filteredProjects,
      favorites: filteredProjects.filter((project) => project.is_favorite),
      others: filteredProjects.filter((project) => !project.is_favorite),
    };
  }, [list, query]);

  useEffect(() => {
    if (!open) return;
    setQuery("");
    setHighlightedId(null);
    const timer = window.setTimeout(() => searchRef.current?.focus(), 60);
    return () => window.clearTimeout(timer);
  }, [open]);

  useEffect(() => {
    if (!filtered.some((project) => project._id === highlightedId)) {
      setHighlightedId(filtered[0]?._id || null);
    }
  }, [filtered, highlightedId]);

  const select = (pid) => {
    setCurrentProjectId(pid);
    touchProjectOpened(pid);
    onClose();
  };

  const onSearchKeyDown = (event) => {
    if (event.key === "ArrowDown" || event.key === "ArrowUp") {
      event.preventDefault();
      if (!filtered.length) return;
      const index = Math.max(0, filtered.findIndex((project) => project._id === highlightedId));
      const next = event.key === "ArrowDown"
        ? (index + 1) % filtered.length
        : (index - 1 + filtered.length) % filtered.length;
      setHighlightedId(filtered[next]._id);
    }
    if (event.key === "Enter" && highlightedId) {
      event.preventDefault();
      select(highlightedId);
    }
  };

  const openNew = () => { setEditing(null); setEditOpen(true); };
  const onDelete = async (project) => {
    if (!window.confirm(t("حذف «{name}»؟ سيؤدي ذلك إلى حذف محادثاته ورسائله نهائيًا.", { name: project.name }))) return;
    try {
      await deleteProject(project._id);
      toast.success(t("تم حذف المشروع"));
    } catch (e) { toast.error(t(e?.message || "تعذر حذف المشروع")); }
  };
  const onToggleArchive = async (project) => {
    try {
      await updateProject(project._id, { is_archived: !project.is_archived });
      toast.success(project.is_archived ? t("تمت استعادة المشروع") : t("تمت أرشفة المشروع"));
    } catch (e) { toast.error(t(e?.message || "تعذر تحديث حالة المشروع")); }
  };
  const onToggleFavorite = async (project) => {
    try { await updateProject(project._id, { is_favorite: !project.is_favorite }); }
    catch (e) { toast.error(t(e?.message || "تعذر تحديث المفضلة")); }
  };

  return (
    <>
      <Dialog open={open} onOpenChange={(value) => !value && onClose()}>
        <DialogContent className="workspace-dialog workspace-switcher-dialog" dir={dir} data-testid="projects-dialog">
          <div className="workspace-dialog-head">
            <DialogHeader>
              <p className="workspace-kicker">{t("rsvx7 · مساحة العمل")}</p>
              <DialogTitle className="workspace-dialog-title"><Folder aria-hidden="true" /> {t("تبديل المشروع")}</DialogTitle>
              <DialogDescription className="workspace-dialog-description">{t("اختر السياق الذي تريد الكتابة والعمل داخله.")}</DialogDescription>
            </DialogHeader>
            <ActionButton onClick={openNew} data-testid="new-project-btn"><FolderPlus aria-hidden="true" /> {t("مشروع جديد")}</ActionButton>
          </div>

          <div className="workspace-switcher-toolbar">
            <div className="workspace-search-field">
              <Search aria-hidden="true" />
              <Input
                ref={searchRef}
                value={query}
                onChange={(event) => setQuery(event.target.value)}
                onKeyDown={onSearchKeyDown}
                placeholder={t("ابحث في المشاريع…")}
                data-testid="projects-search-input"
                className="ds-input"
                aria-label={t("البحث في المشاريع")}
                aria-controls="project-list"
                aria-activedescendant={highlightedId ? `project-option-${highlightedId}` : undefined}
              />
              <kbd>↑↓ Enter</kbd>
            </div>
          </div>

          <div className="workspace-tabs" role="tablist" aria-label={t("حالة المشاريع")}>
            <button
              type="button"
              role="tab"
              aria-selected={!showArchived}
              onClick={() => setShowArchived(false)}
              data-testid="tab-active-projects"
              className={!showArchived ? "is-active" : ""}
            >{t("نشطة")} <span>{formatNumber(projects.length)}</span></button>
            <button
              type="button"
              role="tab"
              aria-selected={showArchived}
              onClick={() => setShowArchived(true)}
              data-testid="tab-archived-projects"
              className={showArchived ? "is-active" : ""}
            >{t("مؤرشفة")} <span>{formatNumber(archivedProjects.length)}</span></button>
          </div>

          <div className="workspace-project-list" id="project-list" role="listbox" aria-label={t("قائمة المشاريع")}>
            {filtered.length === 0 && (
              <div className="workspace-empty-list">
                <Folder aria-hidden="true" />
                <strong>{showArchived ? t("لا توجد مشاريع مؤرشفة") : t("لا توجد نتائج")}</strong>
                <span>{showArchived ? t("ستظهر المشاريع هنا بعد أرشفتها.") : t("جرّب كلمة أخرى أو أنشئ مشروعًا جديدًا.")}</span>
                {!showArchived && <ActionButton tone="ghost" onClick={openNew}>{t("إنشاء أول مشروع")}</ActionButton>}
              </div>
            )}
            {favorites.length > 0 && <ProjectGroup
              label={t("المفضلة")}
              projects={favorites}
              currentProjectId={currentProjectId}
              highlightedId={highlightedId}
              onHighlight={setHighlightedId}
              onSelect={select}
              onEdit={(project) => { setEditing(project); setEditOpen(true); }}
              onDelete={onDelete}
              onArchive={onToggleArchive}
              onFavorite={onToggleFavorite}
            />}
            {others.length > 0 && <ProjectGroup
              label={showArchived ? t("المشاريع المؤرشفة") : t("كل المشاريع")}
              projects={others}
              currentProjectId={currentProjectId}
              highlightedId={highlightedId}
              onHighlight={setHighlightedId}
              onSelect={select}
              onEdit={(project) => { setEditing(project); setEditOpen(true); }}
              onDelete={onDelete}
              onArchive={onToggleArchive}
              onFavorite={onToggleFavorite}
            />}
          </div>
          <p className="workspace-shortcuts"><kbd>↑</kbd><kbd>↓</kbd> {t("للتنقل")} <kbd>Enter</kbd> {t("للاختيار")} <kbd>Esc</kbd> {t("للإغلاق")}</p>
        </DialogContent>
      </Dialog>

      <EditProjectDialog open={editOpen} project={editing} onClose={() => setEditOpen(false)} />
    </>
  );
}

function ProjectGroup({ label, projects, ...props }) {
  return (
    <section className="workspace-project-group">
      <h3>{label}</h3>
      <div>
        {projects.map((project) => <ProjectRow key={project._id} project={project} {...props} />)}
      </div>
    </section>
  );
}

function ProjectRow({ project, currentProjectId, highlightedId, onHighlight, onSelect, onEdit, onDelete, onArchive, onFavorite }) {
  const { t, formatNumber } = useI18n("workspace");
  const active = project._id === currentProjectId;
  const highlighted = project._id === highlightedId;
  const count = project.conversation_count ?? 0;
  const handleKeyDown = (event) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      onSelect(project._id);
    }
  };
  return (
    <div
      role="option"
      aria-selected={active}
      id={`project-option-${project._id}`}
      tabIndex={0}
      onMouseEnter={() => onHighlight(project._id)}
      onClick={() => onSelect(project._id)}
      onKeyDown={handleKeyDown}
      data-testid={`project-row-${project._id}`}
      className={`workspace-project-row${active ? " is-current" : ""}${highlighted ? " is-highlighted" : ""}`}
    >
      <div className="workspace-project-icon" style={{ "--project-color": project.color || WORKSPACE_BRAND_COLOR }}>
        <ProjectIcon name={project.icon} />
      </div>
      <div className="workspace-project-copy">
        <div className="workspace-project-name" dir="auto">
          <span>{project.name}</span>
          {active && <Check aria-label={t("المشروع الحالي")} />}
          {project.is_favorite && <Star aria-label={t("مفضلة")} className="is-favorite" />}
        </div>
        <div className="workspace-project-meta" dir="auto">{project.description || t("{count} محادثة", { count: formatNumber(count) })}</div>
      </div>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button
            type="button"
            onClick={(event) => event.stopPropagation()}
            data-testid={`project-menu-${project._id}`}
            className="workspace-row-menu"
            aria-label={t("خيارات {name}", { name: project.name })}
          ><MoreHorizontal aria-hidden="true" /></button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="workspace-menu" onClick={(event) => event.stopPropagation()}>
          <DropdownMenuItem onClick={(event) => { event.stopPropagation(); onEdit(project); }}><Pencil aria-hidden="true" /> {t("تعديل")}</DropdownMenuItem>
          <DropdownMenuItem onClick={(event) => { event.stopPropagation(); onFavorite(project); }}><Star aria-hidden="true" /> {project.is_favorite ? t("إزالة من المفضلة") : t("إضافة إلى المفضلة")}</DropdownMenuItem>
          <DropdownMenuItem onClick={(event) => { event.stopPropagation(); onArchive(project); }}>{project.is_archived ? <><ArchiveRestore aria-hidden="true" /> {t("استعادة")}</> : <><Archive aria-hidden="true" /> {t("أرشفة")}</>}</DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={(event) => { event.stopPropagation(); onDelete(project); }} className="workspace-danger-item"><Trash2 aria-hidden="true" /> {t("حذف المشروع")}</DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
