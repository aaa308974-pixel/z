import React, { useCallback, useEffect, useRef, useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { useI18n } from "@/i18n";
import "@/i18n/catalogs/admin";
import { Send, Plus, Trash2, Pencil, GripVertical, Save, X, ExternalLink, RefreshCw, ArrowUp, ArrowDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { ActionButton, EmptyState, LoadingState, PageHeader, Panel, StatusNote } from "@/components/design/Primitives";
import "./admin-ui.css";

const BACKEND = (process.env.REACT_APP_BACKEND_URL || "");
const GROUP_HANDLE_RE = /^@[A-Za-z0-9_]{1,32}$/;
const NEGATIVE_CHAT_ID_RE = /^-\d+$/;
const CACHE_TTL = 10_000;
const groupsCache = new Map();

export function safeInviteLink(value) {
  const raw = typeof value === "string" ? value.trim() : "";
  if (!raw) return "";
  try {
    const parsed = new URL(raw);
    if (!(parsed.protocol === "http:" || parsed.protocol === "https:") || !parsed.hostname) return "";
    return raw;
  } catch { return ""; }
}

export function validateGroupPayload(value) {
  const username = String(value?.username || "").trim();
  const invite_link = safeInviteLink(value?.invite_link);
  const rawInviteLink = typeof value?.invite_link === "string" ? value.invite_link.trim() : "";
  if (!(GROUP_HANDLE_RE.test(username) || NEGATIVE_CHAT_ID_RE.test(username))) throw new Error("اسم المستخدم يجب أن يكون @handle أو معرّف دردشة رقميًا سالبًا");
  if (rawInviteLink && !invite_link) throw new Error("رابط الدعوة يجب أن يكون عنوان HTTP(S) مطلقًا");
  if (NEGATIVE_CHAT_ID_RE.test(username) && (!invite_link || new URL(invite_link).protocol !== "https:")) throw new Error("المجموعات الرقمية الخاصة تتطلب رابط دعوة HTTPS");
  return { ...value, username, invite_link: invite_link || null };
}

function errorMessage(error, fallback = "فشل الطلب") { return error?.message || (typeof error === "string" ? error : fallback); }
function _auth() { const token = localStorage.getItem("rsvx7_token") || ""; return token ? { Authorization: `Bearer ${token}` } : {}; }
async function _json(r) {
  if (!r || !r.ok) {
    let message = `فشل الطلب HTTP ${r?.status || 0}`;
    try { const body = await r.json(); const detail = body?.detail; message = typeof detail === "string" ? detail : (detail?.message || detail?.detail || message); } catch { /* retain HTTP status */ }
    throw new Error(message);
  }
  return r.json();
}
const requestOptions = (signal) => ({ headers: _auth(), credentials: "include", signal });
const listGroups = (signal) => fetch(`${BACKEND}/api/admin/telegram-groups`, requestOptions(signal)).then(_json);
const addGroup = (body, signal) => fetch(`${BACKEND}/api/admin/telegram-groups`, { ...requestOptions(signal), method: "POST", headers: { ..._auth(), "Content-Type": "application/json" }, body: JSON.stringify(body) }).then(_json);
const editGroup = (gid, body, signal) => fetch(`${BACKEND}/api/admin/telegram-groups/${gid}`, { ...requestOptions(signal), method: "PATCH", headers: { ..._auth(), "Content-Type": "application/json" }, body: JSON.stringify(body) }).then(_json);
const deleteGroup = (gid, signal) => fetch(`${BACKEND}/api/admin/telegram-groups/${gid}`, { ...requestOptions(signal), method: "DELETE" }).then(_json);
const reorderGroups = (group_ids, signal) => fetch(`${BACKEND}/api/admin/telegram-groups/reorder`, { ...requestOptions(signal), method: "POST", headers: { ..._auth(), "Content-Type": "application/json" }, body: JSON.stringify({ group_ids }) }).then(_json);
const toggleVerification = (enabled, signal) => fetch(`${BACKEND}/api/admin/settings/telegram-verification`, { ...requestOptions(signal), method: "POST", headers: { ..._auth(), "Content-Type": "application/json" }, body: JSON.stringify({ enabled }) }).then(_json);

export default function AdminTelegramVerify() {
  const { user } = useAuth();
  const { t, dir, formatNumber } = useI18n("admin");
  const displayError = (message) => { const match = /^فشل الطلب HTTP (\d+)$/.exec(message || ""); return match ? t("فشل الطلب HTTP {status}", { status: match[1] }) : t(message); };
  const [enabled, setEnabled] = useState(false);
  const [groups, setGroups] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [draft, setDraft] = useState({ username: "", name: "", invite_link: "" });
  const [editing, setEditing] = useState(null);
  const [editingForm, setEditingForm] = useState({});
  const [dragging, setDragging] = useState(null);
  const [saving, setSaving] = useState(false);
  const abortRef = useRef(null);
  const requestId = useRef(0);
  const key = `telegram-groups:${user?._id || user?.id || user?.username || "session"}`;

  const load = useCallback(async ({ force = false } = {}) => {
    const cached = groupsCache.get(key);
    if (!force && cached && Date.now() - cached.at < CACHE_TTL) { setEnabled(cached.enabled); setGroups(cached.groups); setError(""); setLoading(false); return; }
    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;
    const id = ++requestId.current;
    setLoading(true); setError("");
    try {
      const response = await listGroups(controller.signal);
      if (controller.signal.aborted || id !== requestId.current) return;
      const next = { enabled: !!response.enabled, groups: Array.isArray(response.groups) ? response.groups : [] };
      groupsCache.set(key, { ...next, at: Date.now() });
      setEnabled(next.enabled); setGroups(next.groups);
    } catch (e) {
      if (e?.name === "AbortError") return;
      if (id === requestId.current) setError(errorMessage(e, "تعذّر تحميل مجموعات Telegram."));
    } finally { if (id === requestId.current) setLoading(false); }
  }, [key]);

  useEffect(() => { load(); return () => abortRef.current?.abort(); }, [load]);

  const onToggle = async (value) => {
    const previous = enabled;
    setEnabled(value); setSaving(true); setError("");
    try { await toggleVerification(value); groupsCache.delete(key); toast.success(value ? t("تمكين التحقق") : t("تعطيل التحقق")); }
    catch (e) { setEnabled(previous); setError(errorMessage(e)); toast.error(displayError(errorMessage(e))); }
    finally { setSaving(false); }
  };

  const onAdd = async () => {
    let payload;
    try { payload = validateGroupPayload(draft); } catch (e) { setError(errorMessage(e)); toast.error(displayError(errorMessage(e))); return; }
    setSaving(true); setError("");
    try { const g = await addGroup(payload); setGroups((p) => [...p, g]); groupsCache.delete(key); setDraft({ username: "", name: "", invite_link: "" }); toast.success(t("تمت إضافة المجموعة")); }
    catch (e) { setError(errorMessage(e)); toast.error(displayError(errorMessage(e))); }
    finally { setSaving(false); }
  };

  const onSaveEdit = async () => {
    let payload;
    try { payload = validateGroupPayload(editingForm); } catch (e) { setError(errorMessage(e)); toast.error(displayError(errorMessage(e))); return; }
    setSaving(true); setError("");
    try { const g = await editGroup(editing, payload); setGroups((p) => p.map((x) => (x._id === editing ? g : x))); groupsCache.delete(key); setEditing(null); toast.success(t("تم الحفظ")); }
    catch (e) { setError(errorMessage(e)); toast.error(displayError(errorMessage(e))); }
    finally { setSaving(false); }
  };

  const onDelete = async (gid) => {
    if (!window.confirm(t("إزالة هذه المجموعة من قائمة المجموعات المطلوبة؟"))) return;
    setSaving(true); setError("");
    try { await deleteGroup(gid); setGroups((p) => p.filter((g) => g._id !== gid)); groupsCache.delete(key); toast.success(t("تمت إزالة المجموعة")); }
    catch (e) { setError(errorMessage(e)); toast.error(displayError(errorMessage(e))); }
    finally { setSaving(false); }
  };

  const moveTo = async (from, to) => {
    if (from === null || from === to || to < 0 || to >= groups.length) return;
    const next = groups.slice(); const [item] = next.splice(from, 1); next.splice(to, 0, item); setGroups(next); setSaving(true); setError("");
    try { await reorderGroups(next.map((g) => g._id)); groupsCache.delete(key); }
    catch (e) { setError(errorMessage(e)); toast.error(displayError(errorMessage(e))); await load({ force: true }); }
    finally { setSaving(false); }
  };

  return (
    <section className="admin-section space-y-4" dir={dir} data-testid="admin-telegram-verify">
      <PageHeader eyebrow={t("الوصول · Telegram")} title={t("التحقق من عضوية Telegram")} description={t("أدر المجموعات المطلوبة. عند التفعيل يجب أن يكون المستخدم عضوًا في كل مجموعة قبل استخدام rsvx7.")} actions={<ActionButton tone="ghost" onClick={() => load({ force: true })} loading={loading} aria-label={t("تحديث مجموعات Telegram")}><RefreshCw size={16} /> {t("تحديث")}</ActionButton>} />
      {error && <StatusNote tone="error" onRetry={() => load({ force: true })}>{displayError(error)}</StatusNote>}
      <Panel className="admin-content-card" style={{ padding: "16px" }}><div className="flex items-start justify-between gap-4"><div><div className="text-sm font-medium text-white flex items-center gap-2"><Send className="w-4 h-4 text-brand-400" /> {t("تفعيل بوابة العضوية")}</div><p className="admin-subtitle mt-1">{t("يجب أن يكون البوت عضوًا (ويُفضّل مشرفًا) في كل مجموعة ليستدعي ")}<code dir="ltr">getChatMember</code>.</p></div><Switch checked={enabled} disabled={saving} onCheckedChange={onToggle} data-testid="tg-verify-toggle" /></div></Panel>
      <Panel className="admin-content-card" style={{ padding: "16px" }}><div className="ds-field"><Label>{t("إضافة مجموعة مطلوبة")}</Label><div className="grid grid-cols-1 sm:grid-cols-4 gap-2 mt-2"><Input placeholder={t("@rsvx7 أو -100…")} value={draft.username} onChange={(e) => setDraft({ ...draft, username: e.target.value })} data-testid="tg-add-username" className="ds-input admin-code" /><Input placeholder={t("اسم العرض (اختياري)")} value={draft.name} onChange={(e) => setDraft({ ...draft, name: e.target.value })} data-testid="tg-add-name" className="ds-input" /><Input placeholder={t("رابط الدعوة (اختياري)")} value={draft.invite_link} onChange={(e) => setDraft({ ...draft, invite_link: e.target.value })} data-testid="tg-add-invite" className="ds-input admin-code" /><ActionButton onClick={onAdd} loading={saving} data-testid="tg-add-btn"><Plus size={16} /> {t("إضافة")}</ActionButton></div></div></Panel>
      <Panel className="admin-content-card" style={{ padding: 0 }} data-testid="tg-groups-list"><div className="px-4 py-3 border-b border-soft flex items-center justify-between"><span className="text-sm font-medium text-white">{t("المجموعات المطلوبة")} <span className="admin-soft-note">({formatNumber(groups.length)})</span></span><span className="admin-soft-note">{t("اسحب أو استخدم الأسهم للترتيب")}</span></div>{loading && <LoadingState label={t("جارٍ تحميل المجموعات…")} />}{!loading && !error && groups.length === 0 && <EmptyState title={t("لا توجد مجموعات مهيأة")} description={t("أضف مجموعة عامة أو معرّفًا رقميًا سالبًا مع رابط HTTPS خاص.")} />}{!loading && groups.map((g, i) => <div key={g._id} draggable onDragStart={() => setDragging(i)} onDragOver={(e) => e.preventDefault()} onDrop={() => { moveTo(dragging, i); setDragging(null); }} data-testid={`tg-group-row-${g._id}`} className={`group flex items-center gap-3 px-4 py-3 border-b border-soft last:border-b-0 ${dragging === i ? "bg-brand-500/5 opacity-60" : "hover:bg-white/[0.03]"}`}><GripVertical className="w-4 h-4 text-zinc-500 cursor-grab" aria-hidden="true" /><div className="flex-1 min-w-0">{editing === g._id ? <div className="grid grid-cols-1 sm:grid-cols-3 gap-2"><Input value={editingForm.username || ""} onChange={(e) => setEditingForm({ ...editingForm, username: e.target.value })} className="ds-input admin-code" aria-label={t("معرّف المجموعة")} /><Input value={editingForm.name || ""} onChange={(e) => setEditingForm({ ...editingForm, name: e.target.value })} className="ds-input" aria-label={t("اسم المجموعة")} /><Input value={editingForm.invite_link || ""} onChange={(e) => setEditingForm({ ...editingForm, invite_link: e.target.value })} className="ds-input admin-code" aria-label={t("رابط الدعوة")} /></div> : <div><div className="text-sm text-white font-medium flex items-center gap-2"><span dir="ltr" className="admin-code text-brand-400">{g.username}</span>{g.name && g.name !== g.username && <span dir="auto" className="text-zinc-400">· {g.name}</span>}</div>{safeInviteLink(g.invite_link) && <a href={safeInviteLink(g.invite_link)} target="_blank" rel="noopener noreferrer" className="text-[11px] text-zinc-500 hover:text-brand-400 inline-flex items-center gap-1 mt-0.5"><ExternalLink className="w-3 h-3" /> <span dir="ltr" className="admin-code">{safeInviteLink(g.invite_link)}</span></a>}</div>}</div>{editing === g._id ? <><button type="button" onClick={onSaveEdit} disabled={saving} data-testid={`tg-save-${g._id}`} className="admin-icon-button p-1.5 rounded text-emerald-400 hover:bg-white/10" aria-label={t("حفظ التعديل")}><Save className="w-4 h-4" /></button><button type="button" onClick={() => setEditing(null)} disabled={saving} className="admin-icon-button p-1.5 rounded text-zinc-500 hover:bg-white/10" aria-label={t("إلغاء التعديل")}><X className="w-4 h-4" /></button></> : <div className="admin-inline-actions"><button type="button" disabled={saving || i === 0} onClick={() => moveTo(i, i - 1)} className="admin-icon-button p-1.5 rounded text-zinc-400 hover:bg-white/10 disabled:opacity-30" aria-label={t("تحريك {username} للأعلى", { username: g.username })}><ArrowUp className="w-4 h-4" /></button><button type="button" disabled={saving || i === groups.length - 1} onClick={() => moveTo(i, i + 1)} className="admin-icon-button p-1.5 rounded text-zinc-400 hover:bg-white/10 disabled:opacity-30" aria-label={t("تحريك {username} للأسفل", { username: g.username })}><ArrowDown className="w-4 h-4" /></button><button type="button" disabled={saving} onClick={() => { setEditing(g._id); setEditingForm({ username: g.username, name: g.name || "", invite_link: g.invite_link || "" }); }} data-testid={`tg-edit-${g._id}`} className="admin-icon-button p-1.5 rounded text-zinc-400 hover:bg-white/10" aria-label={t("تعديل {username}", { username: g.username })}><Pencil className="w-4 h-4" /></button><button type="button" disabled={saving} onClick={() => onDelete(g._id)} data-testid={`tg-delete-${g._id}`} className="admin-icon-button p-1.5 rounded text-red-400 hover:bg-red-500/10" aria-label={t("حذف {username}", { username: g.username })}><Trash2 className="w-4 h-4" /></button></div>}</div>)}</Panel>
    </section>
  );
}
