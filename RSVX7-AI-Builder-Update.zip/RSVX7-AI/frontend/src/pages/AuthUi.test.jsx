import React, { act } from "react";
import { createRoot } from "react-dom/client";
import Login from "./Login";
import Register from "./Register";
import Recover from "./Recover";
import ForcePasswordChange from "@/components/ForcePasswordChange";
import TelegramGate from "@/components/TelegramGate";

// Keep auth entrypoints imported in this focused suite so syntax/import regressions are caught.
void Recover;
void ForcePasswordChange;
void TelegramGate;

const mockLogin = jest.fn();
const mockRegister = jest.fn();
const mockActivateSession = jest.fn();
jest.mock("@/context/AuthContext", () => ({ useAuth: () => ({ login: mockLogin, register: mockRegister, activateSession: mockActivateSession }) }));
jest.mock("@/components/design/Primitives", () => ({
  AuthShell: ({ title, className, children, footer }) => <main className={className}><h1>{title}</h1>{children}{footer}</main>,
  Panel: ({ children }) => <section>{children}</section>,
  ActionButton: ({ children, loading, ...props }) => <button {...props} disabled={props.disabled || loading}>{children}</button>,
  StatusNote: ({ children }) => <div role="alert">{children}</div>,
}));

let container;
let root;

beforeEach(() => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  mockLogin.mockReset();
  mockRegister.mockReset();
  mockActivateSession.mockReset();
  container = document.createElement("div");
  document.body.appendChild(container);
  root = createRoot(container);
});

afterEach(async () => {
  await act(async () => root.unmount());
  container.remove();
});

async function setInput(testId, value) {
  await act(async () => {
    const input = container.querySelector(`[data-testid="${testId}"]`);
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set.call(input, value);
    input.dispatchEvent(new Event("input", { bubbles: true }));
  });
}

test("login password toggle is keyboard-accessible and failed requests leave the form usable", async () => {
  mockLogin.mockRejectedValueOnce(new Error("Invalid credentials"));
  await act(async () => root.render(<Login />));
  await setInput("login-username", "new_user");
  await setInput("login-password", "wrong-password");

  const toggle = container.querySelector('[data-testid="login-password-toggle"]');
  expect(toggle.getAttribute("aria-label")).toBe("إظهار كلمة المرور");
  await act(async () => toggle.click());
  expect(container.querySelector('[data-testid="login-password"]').type).toBe("text");
  expect(toggle.getAttribute("aria-pressed")).toBe("true");

  await act(async () => container.querySelector("form").dispatchEvent(new Event("submit", { bubbles: true, cancelable: true })));
  expect(await mockLogin).toHaveBeenCalledWith("new_user", "wrong-password", false);
  expect(container.querySelector('[role="alert"]').textContent).toContain("Invalid credentials");
  expect(container.querySelector('[data-testid="login-submit"]').disabled).toBe(false);
});

test("login keeps the recovery and account-creation actions in the MR7 auth shell", async () => {
  await act(async () => root.render(<Login />));

  expect(container.querySelector(".auth-ui-shell.auth-ui-login")).not.toBeNull();
  expect(container.querySelector('[data-testid="link-recover"]')).not.toBeNull();
  expect(container.querySelector('[data-testid="link-register"]')).not.toBeNull();
  expect(container.querySelector('[data-testid="login-submit"]').textContent).toContain("تسجيل الدخول");
});

test("registration preserves the original username regex before calling the service", async () => {
  await act(async () => root.render(<Register />));
  await setInput("reg-username", "bad name");
  await setInput("reg-password", "safe-password");

  await act(async () => container.querySelector("form").dispatchEvent(new Event("submit", { bubbles: true, cancelable: true })));

  expect(mockRegister).not.toHaveBeenCalled();
  expect(container.querySelector('[role="alert"]').textContent).toContain("الحروف والأرقام");
});
