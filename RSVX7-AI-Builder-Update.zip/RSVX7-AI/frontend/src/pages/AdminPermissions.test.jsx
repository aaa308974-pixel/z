import React, { act } from "react";
import { createRoot } from "react-dom/client";
import Admin from "./Admin";
const mockAuth = { user: null, authFetch: jest.fn(), logout: jest.fn() };
jest.mock("@/context/AuthContext", () => ({ useAuth: () => mockAuth }));
jest.mock("@/components/ui/dropdown-menu", () => {
  const React = require("react");
  const Wrap = ({ children }) => <div>{children}</div>;
  const Item = ({ children, onClick, "data-testid": testId }) => <button onClick={onClick} data-testid={testId}>{children}</button>;
  return { DropdownMenu: Wrap, DropdownMenuContent: Wrap, DropdownMenuTrigger: Wrap, DropdownMenuSeparator: () => null, DropdownMenuItem: Item };
});
let node, root, serial = 0;
const lookup = (id) => node.querySelector(`[data-testid="${id}"]`);
const json = (data) => ({ ok: true, status: 200, json: async () => data });
beforeEach(() => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  global.ResizeObserver = class { observe() {} unobserve() {} disconnect() {} };
  node = document.createElement("div"); document.body.appendChild(node); root = createRoot(node);
  mockAuth.user = { _id: `permission-case-${++serial}`, role: "admin", permissions: [], username: "tester" };
  mockAuth.authFetch.mockReset();
  mockAuth.authFetch.mockImplementation(async (path) => json(path.startsWith("/admin/users") ? [{ _id: "sample", username: "sample", role: "user", status: "active", token_balance: 10 }] : {}));
});
afterEach(async () => { await act(async () => root.unmount()); node.remove(); });
async function mount(permissions) {
  mockAuth.user.permissions = permissions;
  await act(async () => root.render(<Admin onExit={() => {}} />));
  await act(async () => new Promise((resolve) => setTimeout(resolve, 25)));
}

test("users-only permission does not expose payments or Telegram actions", async () => {
  await mount(["users"]);
  expect(lookup("admin-user-row-sample")).not.toBeNull();
  for (const action of ["assign", "add-tokens", "deduct-tokens", "set-tokens", "reset-tokens", "tg-verify", "tg-unlink"]) expect(lookup(`row-${action}-sample`)).toBeNull();
  expect(lookup("row-reset-pw-sample")).not.toBeNull();
});

test("authorized payments and Telegram actions remain accessible", async () => {
  await mount(["users", "payments", "telegram"]);
  for (const action of ["assign", "add-tokens", "deduct-tokens", "set-tokens", "reset-tokens", "tg-verify", "tg-unlink"]) expect(lookup(`row-${action}-sample`)).not.toBeNull();
});

test("settings-only admin cannot send a Telegram test or broadcast", async () => {
  await mount(["settings"]);
  const token = lookup("settings-tg-token");
  expect(token.type).toBe("password"); expect(token.value).toBe("");
  await act(async () => {
    const field = lookup("broadcast-input");
    Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype, "value").set.call(field, "test message");
    field.dispatchEvent(new Event("input", { bubbles: true }));
  });
  expect(lookup("broadcast-input").value).toBe("test message");
  expect(lookup("settings-test-btn").disabled).toBe(true);
  expect(lookup("broadcast-send-btn").disabled).toBe(true);
  expect(mockAuth.authFetch.mock.calls.some(([path]) => path.includes("/telegram/test") || path.includes("/telegram/broadcast"))).toBe(false);
});

test("admin with no permitted tabs sees a clear no-access state", async () => {
  await mount([]);
  expect(node.textContent).toContain("لا توجد صلاحيات إدارة لهذا الحساب");
  expect(lookup("admin-users-table")).toBeNull();
  expect(node.querySelectorAll('[role="tab"]').length).toBe(0);
  expect(mockAuth.authFetch).not.toHaveBeenCalled();
});
