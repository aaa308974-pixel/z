import React, { useState } from "react";
import { Eye, EyeOff } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { ActionButton, AuthShell, Panel, StatusNote } from "@/components/design/Primitives";
import { useI18n } from "@/i18n";
import "@/i18n/catalogs/auth";
import "@/components/auth-ui.css";

function PasswordField({ value, onChange }) {
  const { t } = useI18n("auth");
  const [visible, setVisible] = useState(false);
  return (
    <div className="ds-field auth-ui-field">
      <label className="auth-ui-label" htmlFor="rec-newpw">{t("كلمة المرور الجديدة")}</label>
      <div className="auth-ui-input-wrap has-toggle">
        <input id="rec-newpw" data-testid="rec-newpw" className="ds-input auth-ui-input" type={visible ? "text" : "password"} value={value} onChange={onChange} autoComplete="new-password" placeholder={t("كلمة المرور الجديدة")} required minLength={6} />
        <button type="button" className="auth-ui-toggle" onClick={() => setVisible((current) => !current)} aria-label={visible ? t("إخفاء كلمة المرور") : t("إظهار كلمة المرور")} aria-pressed={visible} data-testid="rec-newpw-toggle">
          {visible ? <EyeOff size={17} aria-hidden="true" /> : <Eye size={17} aria-hidden="true" />}
        </button>
      </div>
    </div>
  );
}

export default function Recover({ onBack }) {
  const { recover } = useAuth();
  const { t, dir } = useI18n("auth");
  const [u, setU] = useState("");
  const [code, setCode] = useState("");
  const [p, setP] = useState("");
  const [busy, setBusy] = useState(false);
  const [newCode, setNewCode] = useState(null);
  const [error, setError] = useState("");

  const submit = async (event) => {
    event.preventDefault();
    setError("");
    setBusy(true);
    try {
      const data = await recover(u.trim(), code.trim(), p);
      setNewCode(data.new_recovery_code);
    } catch (requestError) {
      setError(requestError?.message || "تعذّر استرداد الحساب.");
    } finally {
      setBusy(false);
    }
  };

  if (newCode) {
    return (
      <AuthShell className="auth-ui-shell auth-ui-recovery-result" title={t("تم تحديث كلمة المرور")} subtitle={t("احفظ رمز الاسترداد الجديد؛ الرمز القديم لم يعد صالحًا.")}>
        <Panel className="auth-ui-card auth-ui-recovery" dir={dir}>
          <p className="auth-ui-note">{t("هذا الرمز هو الطريقة الوحيدة لاستعادة الحساب إذا نسيت كلمة المرور الجديدة.")}</p>
          <div className="auth-ui-recovery-code" data-testid="new-recovery" dir="ltr">{newCode}</div>
          <ActionButton type="button" tone="primary" onClick={onBack} className="auth-ui-submit">{t("العودة إلى تسجيل الدخول")}</ActionButton>
        </Panel>
      </AuthShell>
    );
  }

  return (
    <AuthShell className="auth-ui-shell auth-ui-recover" title={t("استرداد الحساب")} subtitle={t("استخدم اسم المستخدم ورمز الاسترداد لتعيين كلمة مرور جديدة.")}>
      <Panel className="auth-ui-card" dir={dir}>
        {error && <StatusNote tone="error">{t(error)}</StatusNote>}
        <form onSubmit={submit} className="ds-form-stack auth-ui-form" noValidate>
          <div className="ds-field auth-ui-field">
            <label className="auth-ui-label" htmlFor="rec-username">{t("اسم المستخدم")}</label>
            <input id="rec-username" data-testid="rec-username" className="ds-input auth-ui-input" value={u} onChange={(event) => setU(event.target.value)} autoComplete="username" placeholder={t("اسم المستخدم")} dir="ltr" required spellCheck="false" />
          </div>
          <div className="ds-field auth-ui-field">
            <label className="auth-ui-label" htmlFor="rec-code">{t("رمز الاسترداد")}</label>
            <input id="rec-code" data-testid="rec-code" className="ds-input auth-ui-input auth-ui-code-block" value={code} onChange={(event) => setCode(event.target.value.toUpperCase())} autoComplete="one-time-code" dir="ltr" placeholder="XXXX-XXXX-XXXX-XXXX" required spellCheck="false" />
            <span className="auth-ui-hint">{t("أدخل الرمز كاملًا كما حفظته عند إنشاء الحساب.")}</span>
          </div>
          <PasswordField value={p} onChange={(event) => setP(event.target.value)} />
          <ActionButton type="submit" loading={busy} tone="primary" data-testid="rec-submit" className="auth-ui-submit">
            {busy ? t("جارٍ إعادة التعيين…") : t("إعادة تعيين كلمة المرور")}
          </ActionButton>
        </form>
        <button type="button" onClick={onBack} className="auth-ui-link" data-testid="rec-back">{t("العودة إلى تسجيل الدخول")}</button>
      </Panel>
    </AuthShell>
  );
}
