import React from "react";
import "./admin-ui.css";

/**
 * Visual-only host for trial details supplied by an existing admin surface.
 * It intentionally performs no requests and invents no trial or permission data.
 */
export default function AdminTrials({ children = null }) {
  return <section className="admin-section admin-trials" data-testid="admin-trials">{children}</section>;
}
