import React, { useDeferredValue, useEffect, useMemo, useRef, useState, useCallback } from "react";
import { useAuth } from "@/context/AuthContext";
import { useI18n } from "@/i18n";
import "@/i18n/catalogs/admin";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Plus, Trash2, Ticket, TrendingUp, History, Coins, RefreshCw, ArrowUpDown } from "lucide-react";
import { ActionButton, EmptyState, LoadingState, MetricCard, PageHeader, Panel, StatusNote } from "@/components/design/Primitives";
import "./admin-ui.css";

const EMPTY = { code: "", description: "", tokens: 10000, max_uses: 0, starts_at: "", expires_at: "", enabled: true, notes: "", repeat_allowed: false };
const CACHE_TTL = 10_000;
const couponsCache = new Map();
function isoOrNull(v) { if (!v) return null; const d = new Date(v); return Number.isNaN(d.getTime()) ? null : d.toISOString(); }
function fmtNum(n, formatNumber) { return formatNumber(n ?? 0); }
function detailOf(data, fallback) { return typeof data?.detail === "string" ? data.detail : fallback; }
function cacheKey(user) { return `coupons:${user?._id || user?.id || user?.username || "session"}`; }
function translateAdminError(message, t) {
  const patterns = [
    [/^فشل تحميل القسائم \((.+)\)$/, "فشل تحميل القسائم ({status})"],
    [/^فشلت العملية \((.+)\)$/, "فشلت العملية ({status})"],
  ];
  const found = patterns.find(([pattern]) => pattern.test(message || ""));
  if (found) { const match = found[0].exec(message); return t(found[1], { status: match[1] }); }
  return t(message);
}

export default function AdminCoupons() {
  const { authFetch, user } = useAuth();
  const { t, dir, formatNumber, formatDate } = useI18n("admin");
  const canManage = user?.role === "super_admin" || user?.permissions?.includes("coupons");
  const [coupons, setCoupons] = useState([]);
  const [stats, setStats] = useState(null);
  const [history, setHistory] = useState([]);
  const [showCreate, setShowCreate] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ ...EMPTY });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [query, setQuery] = useState("");
  const deferredQuery = useDeferredValue(query.trim().toLowerCase());
  const [statusFilter, setStatusFilter] = useState("all");
  const [sortBy, setSortBy] = useState("recent");
  const abortRef = useRef(null);
  const requestId = useRef(0);
  const key = cacheKey(user);

  const load = useCallback(async ({ force = false } = {}) => {
    const cached = couponsCache.get(key);
    if (!force && cached && Date.now() - cached.at < CACHE_TTL) {
      setCoupons(cached.coupons); setStats(cached.stats); setHistory(cached.history); setError(""); setLoading(false); return;
    }
    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;
    const id = ++requestId.current;
    setLoading(true); setError("");
    try {
      const responses = await Promise.all([
        authFetch("/admin/coupons", { signal: controller.signal }),
        authFetch("/admin/coupons/stats", { signal: controller.signal }),
        authFetch("/admin/redemptions", { signal: controller.signal }),
      ]);
      const payloads = await Promise.all(responses.map((r) => r.json().catch(() => ({}))));
      const failedIndex = responses.findIndex((r) => !r.ok);
      if (failedIndex >= 0) throw new Error(detailOf(payloads[failedIndex], `فشل تحميل القسائم (${responses[failedIndex].status})`));
      if (controller.signal.aborted || id !== requestId.current) return;
      const next = { coupons: Array.isArray(payloads[0]) ? payloads[0] : [], stats: payloads[1] || null, history: Array.isArray(payloads[2]) ? payloads[2] : [] };
      couponsCache.set(key, { ...next, at: Date.now() });
      setCoupons(next.coupons); setStats(next.stats); setHistory(next.history);
    } catch (e) {
      if (e?.name === "AbortError") return;
      if (id === requestId.current) setError(e?.message || "تعذّر تحميل القسائم");
    } finally {
      if (id === requestId.current) setLoading(false);
    }
  }, [authFetch, key]);

  useEffect(() => { load(); return () => abortRef.current?.abort(); }, [load]);

  const visibleCoupons = useMemo(() => {
    const result = coupons.filter((c) => {
      const matchesQuery = !deferredQuery || [c._id, c.code, c.description].some((v) => String(v || "").toLowerCase().includes(deferredQuery));
      const status = c.active ? "active" : c.scheduled ? "scheduled" : c.expired ? "expired" : "disabled";
      return matchesQuery && (statusFilter === "all" || status === statusFilter);
    });
    return result.sort((a, b) => {
      if (sortBy === "tokens") return Number(b.tokens || 0) - Number(a.tokens || 0);
      if (sortBy === "uses") return Number(b.used_count || 0) - Number(a.used_count || 0);
      return String(b.created_at || b._id || "").localeCompare(String(a.created_at || a._id || ""));
    });
  }, [coupons, deferredQuery, sortBy, statusFilter]);

  const openCreate = () => { setEditing(null); setForm({ ...EMPTY }); setShowCreate(true); };
  const openEdit = (c) => { setEditing(c._id); setForm({ code: c._id, description: c.description || "", tokens: Number(c.tokens) || 0, max_uses: c.max_uses || 0, starts_at: c.starts_at ? c.starts_at.slice(0, 16) : "", expires_at: c.expires_at ? c.expires_at.slice(0, 16) : "", enabled: !!c.enabled, notes: c.notes || "", repeat_allowed: !!c.repeat_allowed }); setShowCreate(true); };

  const submit = async () => {
    if (!canManage || saving) return;
    if (!form.code.trim()) { toast.error(t("الكود مطلوب")); return; }
    const tokens = Number(form.tokens) || 0;
    if (tokens <= 0) { toast.error(t("يجب أن يكون عدد التوكنات 1 على الأقل")); return; }
    const starts = form.starts_at ? new Date(form.starts_at) : null;
    const expires = form.expires_at ? new Date(form.expires_at) : null;
    if ((starts && Number.isNaN(starts.getTime())) || (expires && Number.isNaN(expires.getTime()))) { toast.error(t("يجب أن تكون التواريخ صالحة")); return; }
    if (starts && expires && expires <= starts) { toast.error(t("يجب أن يكون الانتهاء بعد البداية")); return; }
    const body = { code: form.code.trim().toUpperCase(), description: form.description, tokens, max_uses: Number(form.max_uses) || 0, starts_at: isoOrNull(form.starts_at), expires_at: isoOrNull(form.expires_at), enabled: form.enabled, notes: form.notes, repeat_allowed: form.repeat_allowed };
    const url = editing ? `/admin/coupons/${editing}` : "/admin/coupons";
    setSaving(true);
    try {
      const r = await authFetch(url, { method: editing ? "PATCH" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      const data = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(detailOf(data, `Failed (${r.status})`));
      toast.success(editing ? t("تم تحديث القسيمة") : t("تم إنشاء القسيمة"));
      setShowCreate(false); couponsCache.delete(key); await load({ force: true });
    } catch (e) { toast.error(translateAdminError(e?.message || "فشل", t)); }
    finally { setSaving(false); }
  };

  const del = async (code) => {
    if (!canManage || !window.confirm(t("حذف القسيمة {code}؟", { code }))) return;
    try {
      const r = await authFetch(`/admin/coupons/${code}`, { method: "DELETE" });
      const data = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(detailOf(data, `Failed (${r.status})`));
      toast.success(t("محذوف")); couponsCache.delete(key); await load({ force: true });
    } catch (e) { toast.error(translateAdminError(e?.message || "فشل حذف القسيمة", t)); }
  };

  return (
    <section className="admin-section space-y-4" data-testid="admin-coupons" dir={dir}>
      <PageHeader eyebrow={t("الحوافز · الفوترة")} title={t("القسائم والرصيد")} description={t("أنشئ قسائم الرصيد وراجع الاستردادات الأخيرة. البيانات تُحمّل عند فتح التبويب وتُحدّث عند الطلب.")} actions={<div className="admin-inline-actions"><ActionButton tone="ghost" onClick={() => load({ force: true })} loading={loading} aria-label={t("تحديث القسائم")}><RefreshCw size={16} /> {t("تحديث")}</ActionButton><ActionButton onClick={openCreate} disabled={!canManage} data-testid="new-coupon-btn"><Plus size={16} /> {t("قسيمة جديدة")}</ActionButton></div>} />
      {!canManage && <StatusNote tone="info">{t("عرض للقراءة فقط: تحتاج صلاحية coupons لإنشاء القسائم أو تعديلها أو حذفها.")}</StatusNote>}
      {error && <StatusNote tone="error" onRetry={() => load({ force: true })}>{translateAdminError(error, t)}</StatusNote>}
      {stats && <div className="admin-metrics"><MetricCard label={t("إجمالي القسائم")} value={formatNumber(stats.total)} icon={Ticket} /><MetricCard label={t("نشطة")} value={formatNumber(stats.active)} detail={t("متاحة للاستخدام")} icon={TrendingUp} /><MetricCard label={t("مجدولة")} value={formatNumber(stats.scheduled)} icon={TrendingUp} /><MetricCard label={t("الاستردادات")} value={formatNumber(stats.total_redemptions)} detail={t("{count} توكن موزّع", { count: fmtNum(stats.tokens_distributed, formatNumber) })} icon={History} /></div>}
      <Panel className="admin-content-card" style={{ padding: "16px" }}>
        <div className="admin-toolbar"><div><h2 className="text-lg font-semibold text-white m-0">{t("القسائم")}</h2><p className="admin-subtitle">{t("{visible} من {total} نتيجة", { visible: formatNumber(visibleCoupons.length), total: formatNumber(coupons.length) })}</p></div><div className="admin-toolbar-group"><Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={t("ابحث بالكود أو الوصف…")} className="ds-input" data-testid="coupon-search" /><select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="ds-input" aria-label={t("تصفية حالة القسيمة")} data-testid="coupon-status-filter"><option value="all">{t("كل الحالات")}</option><option value="active">{t("نشطة")}</option><option value="scheduled">{t("مجدولة")}</option><option value="expired">{t("منتهية")}</option><option value="disabled">{t("معطلة")}</option></select><select value={sortBy} onChange={(e) => setSortBy(e.target.value)} className="ds-input" aria-label={t("ترتيب القسائم")}><option value="recent">{t("الأحدث")}</option><option value="tokens">{t("الأكثر توكنًا")}</option><option value="uses">{t("الأكثر استخدامًا")}</option></select></div></div>
        {loading && <LoadingState label={t("جارٍ تحميل القسائم…")} />}
        {!loading && !error && visibleCoupons.length === 0 && <EmptyState title={t(coupons.length ? "لا توجد نتائج مطابقة" : "لا توجد قسائم بعد")} description={t(coupons.length ? "غيّر عبارة البحث أو الفلتر." : "أنشئ أول قسيمة عند توفر صلاحية coupons.")} action={coupons.length ? <ActionButton tone="ghost" onClick={() => { setQuery(""); setStatusFilter("all"); }}>{t("مسح الفلاتر")}</ActionButton> : undefined} />}
        {!loading && !error && visibleCoupons.length > 0 && <div className="ds-table-wrap admin-table-panel"><div className="admin-table-scroll"><table className="ds-table"><thead><tr><th>{t("الكود")}</th><th>{t("التوكن")}</th><th>{t("الاستخدام")}</th><th>{t("الانتهاء")}</th><th>{t("الحالة")}</th><th aria-label={t("إجراءات")} /></tr></thead><tbody>{visibleCoupons.map((c) => <tr key={c._id} data-testid={`coupon-row-${c._id}`}><td><span dir="ltr" className="admin-code text-white">{c._id}</span></td><td><span className="ds-badge ds-badge-brand"><Coins className="w-3 h-3" /> +{fmtNum(c.tokens, formatNumber)}</span></td><td className="text-zinc-300 tabular-nums">{c.used_count || 0}/{c.max_uses || "∞"}</td><td className="text-zinc-400 text-xs">{c.expires_at ? formatDate(c.expires_at) : "—"}</td><td>{c.active ? <Badge className="bg-emerald-500/15 text-emerald-400 border-emerald-500/30">{t("نشط")}</Badge> : c.scheduled ? <Badge className="bg-amber-500/15 text-amber-400 border-amber-500/30">{t("مجدولة")}</Badge> : c.expired ? <Badge className="bg-zinc-500/15 text-zinc-400 border-zinc-500/30">{t("منتهية")}</Badge> : <Badge className="bg-red-500/15 text-red-400 border-red-500/30">{t("معطلة")}</Badge>}</td><td className="text-right whitespace-nowrap">{canManage && <><Button size="sm" variant="ghost" onClick={() => openEdit(c)} data-testid={`edit-coupon-${c._id}`}>{t("تعديل")}</Button><Button size="sm" variant="ghost" onClick={() => del(c._id)} data-testid={`del-coupon-${c._id}`} className="text-red-400 hover:text-red-300"><Trash2 className="w-3.5 h-3.5" /></Button></>}</td></tr>)}</tbody></table></div></div>}
      </Panel>
      <Panel className="admin-content-card" style={{ padding: "16px" }}><div className="admin-toolbar"><div><h2 className="text-lg font-semibold text-white m-0">{t("آخر الاستردادات")}</h2><p className="admin-subtitle">{t("آخر 50 عملية كما يعيدها الخادم.")}</p></div></div><div className="ds-table-wrap admin-table-panel"><div className="admin-table-scroll"><table className="ds-table"><thead><tr><th>{t("الوقت")}</th><th>{t("المستخدم")}</th><th>{t("الكود")}</th><th>{t("التوكن")}</th><th>IP</th></tr></thead><tbody>{history.length === 0 ? <tr><td colSpan={5} className="admin-table-empty"><EmptyState title={t("لا توجد استردادات بعد")} /></td></tr> : history.slice(0, 50).map((h) => <tr key={h._id}><td className="text-zinc-400 text-xs">{formatDate(h.redeemed_at, { dateStyle: "medium", timeStyle: "short" })}</td><td dir="auto" className="text-zinc-300">{h.username}</td><td><span dir="ltr" className="admin-code text-white">{h.code}</span></td><td className="text-brand-400 font-mono tabular-nums">+{fmtNum(h.tokens, formatNumber)}</td><td dir="ltr" className="admin-code text-zinc-500 text-xs">{h.ip || "—"}</td></tr>)}</tbody></table></div></div></Panel>

      <Dialog open={showCreate} onOpenChange={setShowCreate}><DialogContent className="bg-bg-surface border-soft text-white max-w-lg" data-testid="coupon-dialog" dir={dir}><DialogHeader><DialogTitle>{editing ? t("تعديل القسيمة {code}", { code: editing }) : t("قسيمة جديدة")}</DialogTitle></DialogHeader><div className="ds-form-stack"><div className="admin-form-grid"><div className="ds-field"><Label>{t("الكود")}</Label><Input value={form.code} onChange={(e) => setForm((f) => ({ ...f, code: e.target.value.toUpperCase() }))} disabled={!!editing} placeholder="WELCOME10K" className="ds-input admin-code" data-testid="coupon-code" /></div><div className="ds-field"><Label><Coins className="w-3 h-3 text-brand-400 inline" /> {t("التوكن")}</Label><Input type="number" min={1} value={form.tokens} onChange={(e) => setForm((f) => ({ ...f, tokens: e.target.value }))} placeholder="10000" className="ds-input admin-code" data-testid="coupon-tokens" /></div><div className="ds-field admin-form-wide"><Label>{t("الوصف (اختياري، يظهر للمستخدمين)")}</Label><Input value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} placeholder={t("مكافأة ترحيبية")} className="ds-input" /></div><div className="ds-field"><Label>{t("الحد الأقصى للاسترداد (0 = بلا حد)")}</Label><Input type="number" min={0} value={form.max_uses} onChange={(e) => setForm((f) => ({ ...f, max_uses: e.target.value }))} className="ds-input admin-code" data-testid="coupon-max-uses" /></div><div className="ds-field"><Label>{t("تبدأ في (اختياري)")}</Label><Input type="datetime-local" value={form.starts_at} onChange={(e) => setForm((f) => ({ ...f, starts_at: e.target.value }))} className="ds-input" /></div><div className="ds-field"><Label>{t("تنتهي في")}</Label><Input type="datetime-local" value={form.expires_at} onChange={(e) => setForm((f) => ({ ...f, expires_at: e.target.value }))} className="ds-input" /></div><div className="admin-form-wide flex flex-wrap items-center gap-6 pt-1"><label className="flex items-center gap-2 text-sm text-zinc-300"><Switch checked={form.enabled} onCheckedChange={(v) => setForm((f) => ({ ...f, enabled: v }))} data-testid="coupon-enabled" />{t("مفعّلة")}</label><label className="flex items-center gap-2 text-sm text-zinc-300"><Switch checked={form.repeat_allowed} onCheckedChange={(v) => setForm((f) => ({ ...f, repeat_allowed: v }))} />{t("السماح بالتكرار للمستخدم نفسه")}</label></div><div className="ds-field admin-form-wide"><Label>{t("ملاحظات إدارية")}</Label><Textarea rows={2} value={form.notes} onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))} className="ds-textarea" /></div></div></div><DialogFooter><Button variant="ghost" onClick={() => setShowCreate(false)}>{t("إلغاء")}</Button><Button onClick={submit} disabled={!canManage || saving} className="bg-brand-500 hover:bg-brand-600 text-white" data-testid="save-coupon-btn">{saving ? t("جارٍ الحفظ…") : editing ? t("حفظ") : t("إنشاء")}</Button></DialogFooter></DialogContent></Dialog>
    </section>
  );
}
