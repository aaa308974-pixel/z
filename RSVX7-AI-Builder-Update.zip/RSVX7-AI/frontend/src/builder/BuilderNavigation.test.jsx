import React, { act } from 'react';
import { createRoot } from 'react-dom/client';
import BuilderWorkspace from './BuilderWorkspace';
import { createRuntime } from './runtime';
import {BuilderProjectsProvider,useBuilderProjects} from './BuilderProjectsContext';
const mockFetch = jest.fn(), mockRefresh = jest.fn();
let mockProjectId, mockProjectsError;
const mockCreate = jest.fn();
const mockComposer = jest.fn();
const mockProgress = jest.fn();
const mockProgressProps = jest.fn();
const mockEditor = jest.fn();
const mockRuntime = { apply: jest.fn(), dispose: jest.fn(), stop: jest.fn(), runtime: { state: { get: () => ({phase:'idle'}) }, setAgentTasks: jest.fn(), beginTask: jest.fn(), pause: jest.fn(), restoreRepairState: jest.fn(), invalidateChecks: jest.fn() } };
jest.mock('@/context/AuthContext', () => ({ useAuth: () => ({ user: {_id:'alice'}, authFetch: mockFetch }) }));
jest.mock('@/context/TokensContext', () => ({ useTokens: () => ({refresh:mockRefresh}) }));
jest.mock('@/context/ChatContext', () => ({useChat: () => ({prefs:{modelId:'deepdark',deepThink:true,autoSuffix:{enabled:true,text:'Native suffix'}}})}));
jest.mock('./runtime', () => ({createRuntime: jest.fn(() => mockRuntime),readPreviewHealth:()=>undefined}));
jest.mock('./generated-widgets', () => ({BuildProgress:props=>{mockProgress(props.state);mockProgressProps(props);return null;}}));
jest.mock('./CodeEditor', () => props=>{mockEditor(props);return <pre data-testid="editor-source" data-disabled={String(props.disabled)}>{props.value}</pre>;});
jest.mock('@/components/chat/Markdown', () => ({children})=><div>{children}</div>);
jest.mock('@/components/design/ThemeSwitcher', () => ()=>null);
jest.mock('@/components/chat/ChatInput', () => ({controller})=>{mockComposer(controller);return <div><button disabled={controller.isStreaming} onClick={()=>controller.sendMessage('Build a site',[])}>Send native composer</button><button onClick={()=>controller.deactivateDarkMode()}>Disable native instruction</button><button onClick={()=>controller.stop()}>Stop native composer</button></div>;});
let node, root, state;
const response = body => ({ok:true,json:async()=>body});
beforeEach(()=>{localStorage.clear();
  global.IS_REACT_ACT_ENVIRONMENT=true; mockProjectId='p_owned'; mockProjectsError=''; jest.clearAllMocks(); mockCreate.mockResolvedValue({_id:'created'}); mockRuntime.apply.mockReset(); createRuntime.mockImplementation(() => mockRuntime); mockRefresh.mockResolvedValue(undefined);
  Object.defineProperty(window,"crypto",{configurable:true,value:{randomUUID:()=>"fixture-request-uuid"}});
  state={revision:1,files:{'/home/project/index.html':{type:'file',content:'<h1>Existing</h1>'}},messages:[],checks:[],model:'admin/chosen-model',darkMode:true};
  mockFetch.mockImplementation(async(path,options)=>{
    if(path==='/builder/projects') return response([{_id:'p_owned',name:'Old project'},{_id:'p_other',name:'New project'}]);
    if(path.includes('p_other')) return response({...state,files:{'/home/project/new.html':{type:'file',content:'New project source'}}});
    if(path.endsWith('/run')) return response({job:{id:'backend-job',status:'running',mode:'build'}});
    return response(state);
  });
  node=document.createElement('div');document.body.appendChild(node);root=createRoot(node);
});
afterEach(async()=>{await act(async()=>root.unmount());node.remove();});
let projects;
function Probe(){projects=useBuilderProjects();return null;}
async function mount(){await act(async()=>{root.render(<BuilderProjectsProvider><Probe/><BuilderWorkspace/></BuilderProjectsProvider>);await Promise.resolve();});}


test('switching projects persists the current source before opening the requested project',async()=>{
  await mount();
  await act(async()=>mockEditor.mock.calls.at(-1)[0].onChange('Edited old project'));
  const request=mockFetch.getMockImplementation();let finishSave;
  mockFetch.mockImplementation((path,options)=>path.endsWith('/files')?new Promise(resolve=>{finishSave=()=>resolve(response({revision:2}));}):request(path,options));
  let switching;
  await act(async()=>{switching=projects.select('p_other');});
  expect(projects.activeId).toBe('p_owned');
  expect(node.querySelector('[data-testid=editor-source]').textContent).toBe('Edited old project');
  const save=mockFetch.mock.calls.find(([path])=>path.endsWith('/files'));
  expect(JSON.parse(save[1].body)).toMatchObject({revision:1,files:{'/home/project/index.html':{content:'Edited old project'}}});
  await act(async()=>{finishSave();await switching;});
  expect(projects.activeId).toBe('p_other');
  expect(node.querySelector('[data-testid=editor-source]').textContent).toBe('New project source');
});

test('a rejected source save prevents switching and preserves editable source',async()=>{
  await mount();
  await act(async()=>mockEditor.mock.calls.at(-1)[0].onChange('Keep this unsaved source'));
  const request=mockFetch.getMockImplementation();
  mockFetch.mockImplementation((path,options)=>path.endsWith('/files')?Promise.resolve({ok:false,json:async()=>({detail:'Save failed; retry'})}):request(path,options));
  await act(async()=>projects.select('p_other'));
  expect(projects.activeId).toBe('p_owned');
  expect(node.querySelector('[data-testid=editor-source]').textContent).toBe('Keep this unsaved source');
  expect(node.querySelector('[data-testid=builder-error]').textContent).toContain('Save failed; retry');
  expect(mockFetch.mock.calls.some(([path])=>path.includes('/p_other'))).toBe(false);
});

test('the last requested project wins when selections share a pending source save',async()=>{
  await mount();await act(async()=>mockEditor.mock.calls.at(-1)[0].onChange('Source before navigation'));
  const request=mockFetch.getMockImplementation();let finishSave;
  mockFetch.mockImplementation((path,options)=>path.endsWith('/files')?new Promise(resolve=>{finishSave=()=>resolve(response({revision:2}));}):request(path,options));
  let first,latest;
  await act(async()=>{first=projects.select('p_other');latest=projects.select('p_owned');});
  await act(async()=>{finishSave();await first;await latest;});
  expect(projects.activeId).toBe('p_owned');
  expect(node.querySelector('[data-testid=editor-source]').textContent).toBe('Source before navigation');
  expect(mockFetch.mock.calls.filter(([path])=>path.endsWith('/files'))).toHaveLength(1);
});
