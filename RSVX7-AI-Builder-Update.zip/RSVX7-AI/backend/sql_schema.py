"""مخطط MySQL المملوك لوحدة التخزين الجديدة.

كل جدول يحتفظ بنسخة JSON كاملة للتوافق المرن، إضافة إلى أعمدة حقيقية
للهوية والمالك والترتيب والتواريخ والرصيد والحقول التي تدخل في القراءة
والفهارس. لا توجد هنا DROP أو TRUNCATE أو إزالة فهارس.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Final

SCHEMA_VERSION: Final[int] = 2
SCHEMA_TABLE: Final[str] = "rsvx7_schema_version"
LOCK_TABLE: Final[str] = "rsvx7_collection_locks"

# أسماء الجداول ثابتة بالكامل ولا تُبنى من مدخل المستخدم.
COLLECTION_TABLES: Final[dict[str, str]] = {
    "users": "rsvx7_users",
    "usage": "rsvx7_usage",
    "settings": "rsvx7_settings",
    "token_usage_history": "rsvx7_token_usage_history",
    "coupons": "rsvx7_coupons",
    "redemptions": "rsvx7_redemptions",
    "referral_codes": "rsvx7_referral_codes",
    "tg_required_groups": "rsvx7_tg_required_groups",
    "tg_seen": "rsvx7_tg_seen",
    "projects": "rsvx7_projects",
    "conversations": "rsvx7_conversations",
    "messages": "rsvx7_messages",
    "notes": "rsvx7_notes",
    "files": "rsvx7_files",
    "ai_request_leases": "rsvx7_ai_request_leases",
    "status_checks": "rsvx7_status_checks",
    "banned_ips": "rsvx7_banned_ips",
    **{name: "rsvx7_" + name for name in ("remote_servers", "remote_devices", "remote_logs", "remote_chat_sessions", "remote_messages")},
}

# أسماء أعمدة مشتركة يمكن للوحدة الكتابة إليها فقط من هذه الخرائط.
BASE_COLUMNS: Final[tuple[str, ...]] = (
    "doc_id", "user_id", "owner_id", "username", "email", "role", "status",
    "registration_ip", "last_ip",
    "is_owner", "token_balance", "item_order", "order_index", "next_order_index", "date_key", "code", "dedup_key",
    "idempotency_key", "conversation_id", "project_id", "is_archived", "is_favorite",
    "is_pinned", "is_deleted", "enabled", "upload_status", "tokens", "telegram_id",
    "created_at", "updated_at", "registered_at", "last_login", "last_opened_at",
    "redeemed_at", "starts_at", "expires_at", "banned_at", "timestamp", "data",
)


def _table(name: str, extra: str = "", indexes: tuple[str, ...] = ()) -> str:
    # data is the flexible document body; typed columns are deliberately nullable
    # so missing and explicit null remain distinguishable through JSON_CONTAINS_PATH.
    index_sql = "\n".join(indexes)
    return f"""
CREATE TABLE IF NOT EXISTS `{name}` (
  `doc_id` VARCHAR(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `user_id` VARCHAR(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `owner_id` VARCHAR(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `username` VARCHAR(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `email` VARCHAR(320) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `role` VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `status` VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `registration_ip` VARCHAR(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `last_ip` VARCHAR(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `is_owner` TINYINT(1) NULL,
  `token_balance` BIGINT NULL,
  `item_order` BIGINT NULL,
  `order_index` BIGINT NULL,
  `next_order_index` BIGINT NULL,
  `date_key` VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `code` VARCHAR(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `dedup_key` VARCHAR(320) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `idempotency_key` VARCHAR(320) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `conversation_id` VARCHAR(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `project_id` VARCHAR(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `is_archived` TINYINT(1) NULL,
  `is_favorite` TINYINT(1) NULL,
  `is_pinned` TINYINT(1) NULL,
  `is_deleted` TINYINT(1) NULL,
  `enabled` TINYINT(1) NULL,
  `upload_status` VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `tokens` BIGINT NULL,
  `telegram_id` BIGINT NULL,
  `created_at` DATETIME(6) NULL,
  `updated_at` DATETIME(6) NULL,
  `registered_at` DATETIME(6) NULL,
  `last_login` DATETIME(6) NULL,
  `last_opened_at` DATETIME(6) NULL,
  `redeemed_at` DATETIME(6) NULL,
  `starts_at` DATETIME(6) NULL,
  `expires_at` DATETIME(6) NULL,
  `banned_at` DATETIME(6) NULL,
  `timestamp` DATETIME(6) NULL,
  `data` JSON NOT NULL,
  {extra}
  PRIMARY KEY (`doc_id`),
  {index_sql}
  KEY `idx_{name}_user_created` (`user_id`, `created_at`),
  KEY `idx_{name}_updated` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
"""


# DDL is additive and idempotent. Generated key implements a MySQL-compatible
# partial unique Telegram index: unverified users produce NULL and may repeat.
TABLE_DDL: Final[tuple[tuple[str, str], ...]] = (
    (LOCK_TABLE, """
CREATE TABLE IF NOT EXISTS `rsvx7_collection_locks` (
  `lock_key` VARCHAR(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`lock_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
"""),
    ("rsvx7_users", _table(
        "rsvx7_users",
        "`telegram_verified_key` VARCHAR(191) GENERATED ALWAYS AS (CASE WHEN JSON_UNQUOTE(JSON_EXTRACT(`data`, '$.telegram.verified')) IN ('true','1') THEN JSON_UNQUOTE(JSON_EXTRACT(`data`, '$.telegram.telegram_id')) ELSE NULL END) STORED,\n",
        ("UNIQUE KEY `uniq_rsvx7_users_username` (`username`),",
         "UNIQUE KEY `uniq_rsvx7_users_telegram_verified` (`telegram_verified_key`),",
         "KEY `idx_rsvx7_users_registration_ip` (`registration_ip`),",
         "KEY `idx_rsvx7_users_last_ip` (`last_ip`),"),
    )),
    ("rsvx7_usage", _table(
        "rsvx7_usage", indexes=("UNIQUE KEY `uniq_rsvx7_usage_user_date` (`user_id`, `date_key`),",)
    )),
    ("rsvx7_settings", _table("rsvx7_settings", indexes=("UNIQUE KEY `uniq_rsvx7_settings_id` (`doc_id`),",))),
    ("rsvx7_token_usage_history", _table(
        "rsvx7_token_usage_history",
        indexes=("UNIQUE KEY `uniq_rsvx7_charge_idempotency` (`user_id`, `idempotency_key`),",
                 "KEY `idx_rsvx7_token_usage_history_conversation` (`conversation_id`),"),
    )),
    ("rsvx7_coupons", _table("rsvx7_coupons", indexes=("KEY `idx_rsvx7_coupons_expires` (`expires_at`),",))),
    ("rsvx7_redemptions", _table(
        "rsvx7_redemptions",
        indexes=("UNIQUE KEY `uniq_rsvx7_redemptions_dedup` (`dedup_key`),",
                 "KEY `idx_rsvx7_redemptions_user_code` (`user_id`, `code`),",
                 "KEY `idx_rsvx7_redemptions_redeemed` (`redeemed_at`),"),
    )),
    ("rsvx7_referral_codes", _table(
        "rsvx7_referral_codes", indexes=("UNIQUE KEY `uniq_rsvx7_referral_user` (`user_id`),",)
    )),
    ("rsvx7_tg_required_groups", _table(
        "rsvx7_tg_required_groups", indexes=("KEY `idx_rsvx7_tg_groups_order` (`item_order`),",)
    )),
    ("rsvx7_tg_seen", _table("rsvx7_tg_seen", indexes=("KEY `idx_rsvx7_tg_seen_telegram` (`telegram_id`),",))),
    ("rsvx7_projects", _table(
        "rsvx7_projects", indexes=(
            "KEY `idx_rsvx7_projects_owner_archive_opened` (`user_id`, `is_archived`, `last_opened_at`),",
            "KEY `idx_rsvx7_projects_owner_favorite` (`user_id`, `is_favorite`),",
        )
    )),
    ("rsvx7_conversations", _table(
        "rsvx7_conversations", indexes=(
            "KEY `idx_rsvx7_conversations_project_pin_updated` (`user_id`, `project_id`, `is_pinned`, `updated_at`),",
            "KEY `idx_rsvx7_conversations_owner_updated` (`user_id`, `updated_at`),",
        )
    )),
    ("rsvx7_messages", _table(
        "rsvx7_messages", indexes=(
            "KEY `idx_rsvx7_messages_conversation_order` (`conversation_id`, `order_index`),",
            "KEY `idx_rsvx7_messages_owner_created` (`user_id`, `created_at`),",
        )
    )),
    ("rsvx7_notes", _table(
        "rsvx7_notes", indexes=("KEY `idx_rsvx7_notes_project_created` (`user_id`, `project_id`, `created_at`),",)
    )),
    ("rsvx7_files", _table(
        "rsvx7_files", indexes=(
            "KEY `idx_rsvx7_files_project_deleted_created` (`user_id`, `project_id`, `is_deleted`, `created_at`),",
            "KEY `idx_rsvx7_files_project_status_deleted` (`user_id`, `project_id`, `upload_status`, `is_deleted`),",
        )
    )),
    ("rsvx7_ai_request_leases", _table(
        "rsvx7_ai_request_leases", indexes=("KEY `idx_rsvx7_leases_expires` (`expires_at`),",)
    )),
    ("rsvx7_status_checks", _table("rsvx7_status_checks", indexes=("KEY `idx_rsvx7_status_timestamp` (`timestamp`),",))),
    ("rsvx7_banned_ips", _table("rsvx7_banned_ips", indexes=("KEY `idx_rsvx7_banned_banned_at` (`banned_at`),",))),
)


@dataclass(frozen=True)
class Migration:
    version: int
    statements: tuple[str, ...]
    description: str


MIGRATIONS: Final[tuple[Migration, ...]] = (
    Migration(
        1,
        tuple(statement.strip() for _, statement in TABLE_DDL),
        "الجداول الصريحة والفهارس اللازمة لعقود التخزين الحالية",
    ),
)

# Isolated tables for remote devices; version 1 DDL remains unchanged.
REMOTE_DDL = tuple(_table('rsvx7_' + name,
    extra=("`device_identity` VARCHAR(191) GENERATED ALWAYS AS (JSON_UNQUOTE(JSON_EXTRACT(`data`, '$.device_id'))) STORED," if name == 'remote_devices' else ''),
    indexes=(("UNIQUE KEY `uniq_rsvx7_remote_device` (`device_identity`),",) if name == 'remote_devices' else ()))
    for name in ('remote_servers','remote_devices','remote_logs','remote_chat_sessions','remote_messages'))
MIGRATIONS = (*MIGRATIONS, Migration(2, REMOTE_DDL, 'Isolated remote control workspace documents'))

# create_index compatibility: old application ensure_indexes calls are accepted
# only when they name an already declared SQL index; no arbitrary DDL is emitted.
DECLARED_INDEXES: Final[dict[str, frozenset[str]]] = {
    collection: frozenset(
        name for name in (
            "uniq_rsvx7_users_username", "uniq_rsvx7_users_telegram_verified",
            "uniq_rsvx7_usage_user_date", "uniq_rsvx7_charge_idempotency",
            "uniq_rsvx7_redemptions_dedup", "uniq_rsvx7_referral_user",
            "idx_rsvx7_tg_groups_order", "idx_rsvx7_projects_owner_archive_opened",
            "idx_rsvx7_projects_owner_favorite", "idx_rsvx7_conversations_project_pin_updated",
            "idx_rsvx7_conversations_owner_updated", "idx_rsvx7_messages_conversation_order",
            "idx_rsvx7_messages_owner_created", "idx_rsvx7_files_project_deleted_created",
            "idx_rsvx7_files_project_status_deleted", "idx_rsvx7_leases_expires",
            "idx_rsvx7_status_timestamp", "idx_rsvx7_banned_banned_at",
        ) if collection in {
            "users", "usage", "token_usage_history", "redemptions", "referral_codes",
            "tg_required_groups", "projects", "conversations", "messages", "files",
            "ai_request_leases", "status_checks", "banned_ips",
        }
    ) for collection in COLLECTION_TABLES
}
# The comprehension above intentionally maps only declared names; explicit extras
# make compatibility checks readable and prevent a typo from becoming DDL.
DECLARED_INDEXES.update({
    "users": frozenset({"uniq_rsvx7_users_username", "uniq_rsvx7_users_telegram_verified", "idx_rsvx7_users_registration_ip", "idx_rsvx7_users_last_ip"}),
    "usage": frozenset({"uniq_rsvx7_usage_user_date"}),
    "token_usage_history": frozenset({"uniq_rsvx7_charge_idempotency", "idx_rsvx7_token_usage_history_user_created", "idx_rsvx7_token_usage_history_conversation"}),
    "coupons": frozenset({"idx_rsvx7_coupons_expires"}),
    "redemptions": frozenset({"uniq_rsvx7_redemptions_dedup", "idx_rsvx7_redemptions_user_code", "idx_rsvx7_redemptions_redeemed"}),
    "referral_codes": frozenset({"uniq_rsvx7_referral_user"}),
    "tg_required_groups": frozenset({"idx_rsvx7_tg_groups_order"}),
    "projects": frozenset({"idx_rsvx7_projects_owner_archive_opened", "idx_rsvx7_projects_owner_favorite"}),
    "conversations": frozenset({"idx_rsvx7_conversations_project_pin_updated", "idx_rsvx7_conversations_owner_updated"}),
    "messages": frozenset({"idx_rsvx7_messages_conversation_order", "idx_rsvx7_messages_owner_created"}),
    "files": frozenset({"idx_rsvx7_files_project_deleted_created", "idx_rsvx7_files_project_status_deleted"}),
    "ai_request_leases": frozenset({"idx_rsvx7_leases_expires"}),
    "status_checks": frozenset({"idx_rsvx7_status_timestamp"}),
    "banned_ips": frozenset({"idx_rsvx7_banned_banned_at"}),
})
