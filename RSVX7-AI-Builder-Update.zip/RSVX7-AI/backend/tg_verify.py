"""rsvx7 — Telegram Group Membership Verification.

Optional gate that admins can enable to require every regular user to be a
member of a configured list of Telegram groups before they can call any AI
feature.

Design:
- Setting `telegram_verification_enabled` (bool) stored in the `settings`
  collection. Off by default.
- Collection `tg_required_groups`: {_id, username, name, invite_link, order,
  created_at, updated_at}. `username` is the public @handle (or `-100…` chat
  id) — the bot must be a member/admin of each group so `getChatMember` works.
- Admins CRUD via `/api/admin/telegram-groups`.
- Users hit `/api/telegram/membership-check` and get a structured result.
- `require_membership(user)` is called by every AI endpoint BEFORE subscription
  gating; on failure it raises 402 with `code: "membership_required"` and the
  list of missing groups so the client can render inline chat buttons.
"""
from __future__ import annotations
import asyncio
import logging
import re
from datetime import datetime, timezone
from typing import Optional, List
from urllib.parse import urlparse
import httpx
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field, ConfigDict, field_validator, model_validator

from auth import db, current_user, require_admin, require_permission

logger = logging.getLogger("tg_verify")

user_router = APIRouter(prefix="/api/telegram")
admin_router = APIRouter(prefix="/api/admin")

MAX_MEMBERSHIP_CONCURRENCY = 5
MEMBERSHIP_TIMEOUT_SECONDS = 8.0
MAX_REQUIRED_GROUPS = 20
_GROUP_HANDLE_RE = re.compile(r"^@[A-Za-z0-9_]{1,32}$")
_NEGATIVE_CHAT_ID_RE = re.compile(r"^-\d+$")
_membership_client: Optional[httpx.AsyncClient] = None


# ────────────── settings helper ──────────────
async def _get_settings() -> dict:
    return await db.settings.find_one({"_id": "app"}) or {}


async def is_verification_enabled() -> bool:
    s = await _get_settings()
    return bool(s.get("telegram_verification_enabled", False))


async def _get_bot_token() -> Optional[str]:
    # SEC-P3: the bot token is written to the "global" settings doc by auth.py::set_settings,
    # while the verification-enabled flag lives in "app". Read whichever has the token.
    g = await db.settings.find_one({"_id": "global"}) or {}
    if g.get("telegram_bot_token"): return g["telegram_bot_token"]
    a = await _get_settings()
    return a.get("telegram_bot_token") or None


# ────────────── validation helpers and models ──────────────
def _is_valid_group_id(value: str) -> bool:
    value = (value or "").strip()
    return bool(_GROUP_HANDLE_RE.fullmatch(value) or _is_negative_chat_id(value))


def _is_negative_chat_id(value: str) -> bool:
    value = (value or "").strip()
    return bool(_NEGATIVE_CHAT_ID_RE.fullmatch(value)) and int(value) < 0


def _validate_invite_link(value: Optional[str]) -> Optional[str]:
    """Allow only absolute HTTP(S) URLs; never persist script/data schemes."""
    if value is None:
        return None
    value = str(value).strip()
    if not value:
        return None
    parsed = urlparse(value)
    if parsed.scheme.lower() not in ("http", "https") or not parsed.hostname:
        raise ValueError("invite_link must be an absolute http(s) URL")
    return value


def _validate_group_payload(username: str, invite_link: Optional[str]) -> tuple[str, Optional[str]]:
    username = (username or "").strip()
    if not _is_valid_group_id(username):
        raise ValueError("username must be an @handle or a negative integer chat id")
    invite_link = _validate_invite_link(invite_link)
    if _is_negative_chat_id(username) and not (invite_link and urlparse(invite_link).scheme.lower() == "https"):
        raise ValueError("private numeric groups require an https invite_link")
    return username, invite_link


class GroupBody(BaseModel):
    model_config = ConfigDict(extra="ignore")
    username: str = Field(min_length=2, max_length=64)
    name: Optional[str] = None
    invite_link: Optional[str] = None

    @field_validator("username", mode="before")
    @classmethod
    def validate_username(cls, value: object) -> str:
        value = str(value or "").strip()
        if not _is_valid_group_id(value):
            raise ValueError("username must be an @handle or a negative integer chat id")
        return value

    @field_validator("invite_link", mode="before")
    @classmethod
    def validate_invite(cls, value: object) -> Optional[str]:
        return _validate_invite_link(value if value is not None else None)

    @model_validator(mode="after")
    def validate_private_group(self):
        self.username, self.invite_link = _validate_group_payload(self.username, self.invite_link)
        return self


class ReorderBody(BaseModel):
    model_config = ConfigDict(extra="ignore")
    group_ids: List[str]


class VerificationToggle(BaseModel):
    model_config = ConfigDict(extra="ignore")
    enabled: bool


# ────────────── helpers ──────────────
def _normalize_username(u: str) -> str:
    """Return only accepted Telegram chat-id forms; invalid values fail closed."""
    u = (u or "").strip()
    return u if _is_valid_group_id(u) else ""


async def list_groups(limit: int = MAX_REQUIRED_GROUPS + 1) -> list[dict]:
    """Read only enough groups to detect an over-cap configuration."""
    docs = await db.tg_required_groups.find().sort("order", 1).to_list(limit)
    return [{**d, "_id": str(d.get("_id"))} for d in docs]


async def ensure_indexes():
    await db.tg_required_groups.create_index("order")


# ────────────── membership check ──────────────
async def _get_membership_client() -> httpx.AsyncClient:
    """Lazily create one process-wide Telegram client for membership checks."""
    global _membership_client
    if _membership_client is None or _membership_client.is_closed:
        _membership_client = httpx.AsyncClient(timeout=MEMBERSHIP_TIMEOUT_SECONDS)
    return _membership_client


async def _check_one(bot_token: str, chat_id: str, tg_user_id: int) -> tuple[bool, str]:
    """Returns (is_member, raw_status). Non-2xx or unknown → (False, err)."""
    if not tg_user_id or not chat_id:
        return False, "missing_id"
    url = f"https://api.telegram.org/bot{bot_token}/getChatMember"
    try:
        c = await _get_membership_client()
        r = await c.get(url, params={"chat_id": chat_id, "user_id": tg_user_id})
        try:
            j = r.json()
        except Exception:
            j = {}
        status_code = getattr(r, "status_code", 200)
        if not (200 <= status_code < 300) or not j.get("ok"):
            return False, j.get("description", f"http_{status_code}")
        result = j.get("result") or {}
        status = result.get("status", "")
        # A restricted user is a member only when Telegram explicitly says so.
        member = bool(result.get("is_member")) if status == "restricted" else status in (
            "creator", "administrator", "member"
        )
        return member, status
    except Exception as e:
        return False, str(e)


async def check_user_membership(user: dict) -> dict:
    """Runs getChatMember for every required group. Returns:
    {enabled, ok, linked, groups: [{_id, username, name, invite_link, joined}]}.
    """
    try:
        enabled = await is_verification_enabled()
        groups = await list_groups()
    except Exception:
        # A verification read failure must never turn the gate into a bypass.
        return {"enabled": True, "ok": False, "linked": False,
                "reason": "verification_unavailable", "groups": []}
    if not enabled or not groups:
        return {"enabled": False, "ok": True, "linked": True, "groups": []}
    if len(groups) > MAX_REQUIRED_GROUPS:
        return {
            "enabled": True, "ok": False, "linked": True,
            "reason": "group_count_exceeded",
            "groups": [{"_id": g["_id"], "username": g.get("username", ""),
                        "name": g.get("name") or g.get("username", ""),
                        "invite_link": g.get("invite_link"), "joined": False}
                       for g in groups[:MAX_REQUIRED_GROUPS]],
        }
    tg = user.get("telegram") or {}
    tg_id = tg.get("telegram_id")
    try:
        bot_token = await _get_bot_token()
    except Exception:
        bot_token = None
    if not bot_token:
        # Enabled but not configured — fail-closed so admins notice
        return {"enabled": True, "ok": False, "linked": False,
                "reason": "bot_not_configured",
                "groups": [{"_id": g["_id"], "username": g["username"],
                            "name": g.get("name") or g["username"],
                            "invite_link": g.get("invite_link"), "joined": False} for g in groups]}
    if not tg_id:
        return {"enabled": True, "ok": False, "linked": False,
                "groups": [{"_id": g["_id"], "username": g["username"],
                            "name": g.get("name") or g["username"],
                            "invite_link": g.get("invite_link"), "joined": False} for g in groups]}
    try:
        tg_id = int(tg_id)
    except (TypeError, ValueError):
        tg_id = None
    if not tg_id:
        return {"enabled": True, "ok": False, "linked": False,
                "groups": [{"_id": g["_id"], "username": g["username"],
                            "name": g.get("name") or g["username"],
                            "invite_link": g.get("invite_link"), "joined": False} for g in groups]}

    # Legacy/malformed documents are treated as not joined without making a
    # Telegram request; this keeps an invalid configuration fail-closed.
    for g in groups:
        try:
            _validate_group_payload(g.get("username", ""), g.get("invite_link"))
        except (TypeError, ValueError):
            return {"enabled": True, "ok": False, "linked": True,
                    "reason": "invalid_group_configuration",
                    "groups": [{"_id": item["_id"], "username": item.get("username", ""),
                                "name": item.get("name") or item.get("username", ""),
                                "invite_link": item.get("invite_link"), "joined": False}
                               for item in groups]}

    semaphore = asyncio.Semaphore(MAX_MEMBERSHIP_CONCURRENCY)

    async def bounded_check(group: dict) -> tuple[bool, str]:
        async with semaphore:
            try:
                return await _check_one(bot_token, _normalize_username(group["username"]), tg_id)
            except Exception as exc:
                return False, str(exc)

    results = await asyncio.gather(*(bounded_check(g) for g in groups), return_exceptions=False)
    out = [{"_id": g["_id"], "username": g["username"],
            "name": g.get("name") or g["username"],
            "invite_link": g.get("invite_link"), "joined": result[0]}
           for g, result in zip(groups, results)]
    all_joined = all(result[0] for result in results)
    return {"enabled": True, "ok": all_joined, "linked": True, "groups": out}


class MembershipRequiredError(HTTPException):
    def __init__(self, check_result: dict):
        super().__init__(
            status_code=402,
            detail={
                "code": "membership_required",
                "linked": check_result.get("linked", True),
                "reason": check_result.get("reason"),
                "message": (
                    "يجب الانضمام إلى جميع مجموعات Telegram التالية قبل استخدام rsvx7."
                    if check_result.get("linked", True) else
                    "يرجى ربط حساب Telegram أولاً، ثم الانضمام إلى المجموعات التالية."
                ),
                "cta": "تحقّق",
                "groups": [g for g in (check_result.get("groups") or []) if not g.get("joined")],
            },
        )


async def require_membership(user: dict):
    """Guard called before subscription/quota checks. No-op when verification is
    disabled or no groups are configured. Admins are exempt."""
    if user.get("role") in ("super_admin", "admin", "moderator", "support"):
        return
    if not await is_verification_enabled():
        return
    groups = await list_groups()
    if not groups:
        return
    res = await check_user_membership(user)
    if not res.get("ok"):
        raise MembershipRequiredError(res)


# ────────────── user endpoints ──────────────
@user_router.get("/membership-check")
async def membership_check(u: dict = Depends(current_user)):
    """Manual verification — used by the "تحقّق" button in the chat gate."""
    return await check_user_membership(u)


# ────────────── admin endpoints ──────────────
@admin_router.get("/telegram-groups")
async def admin_list_groups(_: dict = Depends(require_permission("telegram"))):
    return {
        "enabled": await is_verification_enabled(),
        "groups": await list_groups(limit=200),
    }


@admin_router.post("/telegram-groups")
async def admin_add_group(body: GroupBody, _: dict = Depends(require_permission("telegram"))):
    import secrets
    if await db.tg_required_groups.count_documents({}) >= MAX_REQUIRED_GROUPS:
        raise HTTPException(409, f"At most {MAX_REQUIRED_GROUPS} Telegram groups may be required")
    now = datetime.now(timezone.utc).isoformat()
    username = _normalize_username(body.username)
    max_order = 0
    async for g in db.tg_required_groups.find({}, {"order": 1}).sort("order", -1).limit(1):
        max_order = int(g.get("order", 0))
    gid = "g_" + secrets.token_urlsafe(6)
    doc = {
        "_id": gid, "username": username,
        "name": (body.name or username.lstrip("@")).strip()[:80],
        "invite_link": (body.invite_link or "").strip() or None,
        "order": max_order + 1,
        "created_at": now, "updated_at": now,
    }
    await db.tg_required_groups.insert_one(doc)
    return {**doc, "_id": str(doc.get("_id"))}


@admin_router.patch("/telegram-groups/{gid}")
async def admin_edit_group(gid: str, body: GroupBody, _: dict = Depends(require_permission("telegram"))):
    upd = {
        "username": _normalize_username(body.username),
        "name": (body.name or "").strip()[:80] or _normalize_username(body.username).lstrip("@"),
        "invite_link": (body.invite_link or "").strip() or None,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    r = await db.tg_required_groups.update_one({"_id": gid}, {"$set": upd})
    if not r.matched_count: raise HTTPException(404, "Group not found")
    return await db.tg_required_groups.find_one({"_id": gid})


@admin_router.delete("/telegram-groups/{gid}")
async def admin_delete_group(gid: str, _: dict = Depends(require_permission("telegram"))):
    r = await db.tg_required_groups.delete_one({"_id": gid})
    if not r.deleted_count: raise HTTPException(404, "Group not found")
    return {"ok": True}


@admin_router.post("/telegram-groups/reorder")
async def admin_reorder_groups(body: ReorderBody, _: dict = Depends(require_permission("telegram"))):
    for idx, gid in enumerate(body.group_ids, start=1):
        await db.tg_required_groups.update_one({"_id": gid}, {"$set": {"order": idx}})
    return {"ok": True}


@admin_router.post("/settings/telegram-verification")
async def admin_toggle_verification(body: VerificationToggle, _: dict = Depends(require_permission("settings"))):
    await db.settings.update_one(
        {"_id": "app"},
        {"$set": {"telegram_verification_enabled": bool(body.enabled)}},
        upsert=True,
    )
    return {"ok": True, "enabled": bool(body.enabled)}
