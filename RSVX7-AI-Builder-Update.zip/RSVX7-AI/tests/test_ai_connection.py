"""Owner setup, encrypted credentials, provider probes and concurrent client snapshots."""
import asyncio
import copy
import json
from types import SimpleNamespace
from unittest.mock import AsyncMock

import httpx
import pytest
from fastapi import FastAPI, HTTPException
from fastapi.testclient import TestClient
from tests.test_builder import MemoryDB
import ai_settings, auth, server

KEY_A='fixture-owner-api-key-alpha'
KEY_B='fixture-owner-api-key-beta'
REPORT={'key_valid':True,'model_available':True,'ready':True,'warning':None}
def run(value):return asyncio.run(value)

@pytest.fixture
def store(monkeypatch):
    value=MemoryDB()
    monkeypatch.setattr(ai_settings,'db',value)
    monkeypatch.setattr(ai_settings,'AI_PROVIDER','openrouter')
    monkeypatch.setattr(ai_settings,'API_KEY',None)
    monkeypatch.setattr(ai_settings,'client',None)
    monkeypatch.setattr(ai_settings,'_configured_clients',{})
    monkeypatch.setattr(ai_settings,'AsyncOpenAI',lambda **kwargs:SimpleNamespace(api_key=kwargs['api_key'],close=AsyncMock()))
    monkeypatch.setattr(ai_settings,'BASE_URL','https://openrouter.ai/api/v1')
    return value

def api(role='super_admin',permissions=None):
    app=FastAPI();app.include_router(ai_settings.router)
    app.dependency_overrides[auth.current_user]=lambda:{'_id':'operator','role':role,'permissions':permissions or []}
    return TestClient(app)

def secret(value):return ai_settings.credential_cipher().encrypt(value.encode()).decode()

def test_owner_key_is_encrypted_write_only_and_applies_without_restart(store,monkeypatch):
    probe=AsyncMock(return_value=REPORT);monkeypatch.setattr(ai_settings,'inspect_connection',probe)
    with api() as http:
        first=http.put('/api/admin/ai-settings/connection',json={'revision':0,'api_key':KEY_A})
        assert first.status_code==200,first.text
        assert first.json()['settings']['key_configured'] is True
        assert first.json()['settings']['key_source']=='admin'
        assert KEY_A not in first.text and 'provider_secret' not in first.text
        loaded=http.get('/api/admin/ai-settings').text
        assert KEY_A not in loaded and 'provider_secret' not in loaded
    saved=store.settings.rows['ai'];assert KEY_A not in json.dumps(saved)
    assert ai_settings.configured_key(saved)==KEY_A
    async def selected():
        await ai_settings.current_settings()
        return ai_settings.request_client().api_key
    assert run(selected())==KEY_A


@pytest.mark.parametrize('role,permissions',[('user',[]),('admin',['ai_models']),('support',['ai_models'])])
def test_only_owner_can_change_or_test_a_provider_key(store,monkeypatch,role,permissions):
    probe=AsyncMock(return_value=REPORT);monkeypatch.setattr(ai_settings,'inspect_connection',probe)
    with api(role,permissions) as http:
        for method,path in [('put','/connection'),('post','/connection/test')]:
            assert getattr(http,method)('/api/admin/ai-settings'+path,json={'revision':0,'api_key':KEY_A}).status_code==403
    probe.assert_not_awaited();assert not store.settings.rows


def test_failed_key_probe_and_stale_revision_preserve_saved_key(store,monkeypatch):
    store.settings.rows['ai']={'_id':'ai','connection_revision':3,'provider_secret':secret(KEY_A),'model':'provider/old'}
    probe=AsyncMock(side_effect=HTTPException(400,'رفض المزوّد المفتاح'))
    monkeypatch.setattr(ai_settings,'inspect_connection',probe)
    with api() as http:
        assert http.put('/api/admin/ai-settings/connection',json={'revision':2,'api_key':KEY_B}).status_code==409
        probe.assert_not_awaited()
        assert http.put('/api/admin/ai-settings/connection',json={'revision':3,'api_key':KEY_B}).status_code==400
    assert ai_settings.configured_key(store.settings.rows['ai'])==KEY_A


def test_encryption_key_change_requires_reentry_instead_of_silent_env_fallback(store,monkeypatch):
    store.settings.rows['ai']={'_id':'ai','provider_secret':secret(KEY_A)}
    monkeypatch.setattr(ai_settings,'JWT_SECRET','different-fixture-signing-key-0000000000000')
    monkeypatch.setattr(ai_settings,'API_KEY','environment-fallback-must-not-be-used')
    loaded=run(ai_settings.current_settings())
    assert loaded['key_configured'] is False and loaded['key_reentry_required'] is True


def test_parallel_requests_keep_their_credential_snapshot_during_rotation(store,monkeypatch):
    monkeypatch.setattr(ai_settings,'select_client',lambda key:SimpleNamespace(api_key=key))
    async def scenario():
        ready=asyncio.Event();rotated=asyncio.Event()
        async def first():
            store.settings.rows['ai']={'_id':'ai','provider_secret':secret(KEY_A)}
            await ai_settings.current_settings();ready.set();await rotated.wait()
            return ai_settings.request_client().api_key
        async def second():
            await ready.wait();store.settings.rows['ai']['provider_secret']=secret(KEY_B)
            await ai_settings.current_settings();rotated.set()
            return ai_settings.request_client().api_key
        return await asyncio.gather(first(),second())
    assert run(scenario())==[KEY_A,KEY_B]


@pytest.mark.parametrize('local,quota,warning',[(False,0,'free_limit'),(False,5,None),(True,None,None)])
def test_provider_probe_uses_readonly_endpoints_and_returns_no_account_secrets(store,monkeypatch,local,quota,warning):
    original=httpx.AsyncClient;requests=[]
    if local:monkeypatch.setattr(ai_settings,'AI_PROVIDER','local')
    def handler(request):
        requests.append(request)
        assert request.method=='GET'
        if request.url.path.endswith('/key'):
            assert request.headers['Authorization']=='Bearer '+KEY_A
            return httpx.Response(200,json={'data':{'label':'private-account-label','free_model_daily_requests':{'remaining':quota}}})
        return httpx.Response(200,json={'data':[{'id':'provider/model:free'}]})
    monkeypatch.setattr(ai_settings.httpx,'AsyncClient',lambda **kwargs:original(transport=httpx.MockTransport(handler),**kwargs))
    report=run(ai_settings.inspect_connection(KEY_A,'provider/model:free'))
    assert report['warning']==warning
    assert report['ready']==(warning is None)
    assert KEY_A not in json.dumps(report) and 'private-account-label' not in json.dumps(report)
    assert len(requests)==(1 if local else 2)
    assert not any('completions' in str(request.url) for request in requests)


def test_provider_auth_error_never_exposes_upstream_error_body(store,monkeypatch):
    original=httpx.AsyncClient
    transport=httpx.MockTransport(lambda request:httpx.Response(401,json={'error':{'message':KEY_A}}))
    monkeypatch.setattr(ai_settings.httpx,'AsyncClient',lambda **kwargs:original(transport=transport,**kwargs))
    with pytest.raises(HTTPException) as error:run(ai_settings.inspect_connection(KEY_A,'provider/model'))
    assert error.value.status_code==400 and KEY_A not in str(error.value.detail)


def test_chat_uses_saved_owner_key_even_when_no_environment_client_exists(store,monkeypatch):
    from tests.test_ai_settings_regressions import FakeStream
    stream=FakeStream();create=AsyncMock(return_value=stream);captured=[]
    selected=SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=create)))
    def select(key):captured.append(key);return selected
    monkeypatch.setattr(ai_settings,'select_client',select)
    store.settings.rows['ai']={'_id':'ai','provider_secret':secret(KEY_A),'model':'provider/owner-selected'}
    monkeypatch.setattr(server,'openrouter_client',None)
    monkeypatch.setattr(server,'current_settings',ai_settings.current_settings)
    for name in ('require_membership','check_can_afford','release_generation'):
        monkeypatch.setattr(server,name,AsyncMock())
    monkeypatch.setattr(server,'claim_generation',AsyncMock(return_value='connection-test-lease'))
    monkeypatch.setattr(server,'charge_user',AsyncMock(return_value={'billed_total':1}))
    monkeypatch.setattr(server,'db',SimpleNamespace(users=SimpleNamespace(find_one=AsyncMock(return_value={'token_balance':1}))))
    async def consume():
        response=await server.chat_stream(server.ChatStreamRequest(messages=[{'role':'user','content':'Hello'}]),{'_id':'owner','role':'super_admin'})
        return ''.join([chunk async for chunk in response.body_iterator])
    output=run(consume())
    assert captured==[KEY_A]
    assert create.call_args.kwargs['model']=='provider/owner-selected'
    assert '"t": "OK"' in output and KEY_A not in output
    assert stream.close.await_count==1
