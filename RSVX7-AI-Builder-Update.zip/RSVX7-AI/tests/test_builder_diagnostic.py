import json
from scripts.builder_status import job_summary

def test_diagnostic_excludes_credentials_messages_source_and_account_data():
    project={'_id':'fixture','user_id':'PRIVATE owner','builder':{'phase':'build','files':{'x':'PRIVATE source'},'messages':['PRIVATE message'],
        'job':{'status':'running','model':'synthetic/model','request':{'text':'PRIVATE prompt'},'modelSettings':{'key':'PRIVATE key'},
               'modelCall':{'phase':'receiving','chars':123,'raw':'PRIVATE provider response'},'generation':{'files':4,'batches':2}}}}
    report=job_summary(project)
    assert 'PRIVATE' not in json.dumps(report)
    assert report['modelCall']=={'phase':'receiving','chars':123}
    assert report['generation']=={'files':4,'batches':2}

def test_diagnostic_handles_a_legacy_cancelled_job_without_stream_metadata():
    report=job_summary({'_id':'legacy','builder':{'job':{'status':'cancelled','model':'legacy/model'}}})
    assert report['status']=='cancelled' and report['model']=='legacy/model'
    assert report['modelCall']=={} and report['validation']=={}

def test_diagnostic_reports_pipeline_without_draft_source():
    report=job_summary({'_id':'staged','builder':{'job':{'pipeline':{'stage':'reviewing','completed':2,'total':5,'files':'PRIVATE source'},'draftFiles':{'x':'PRIVATE draft'}}}})
    assert report['pipeline']=={'stage':'reviewing','completed':2,'total':5}
    assert 'PRIVATE' not in json.dumps(report)
